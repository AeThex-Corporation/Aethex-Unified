import React from 'react';
import { InterfaceMode, UserProfile } from '../types';
import { ShieldCheck, Hexagon, QrCode, Fingerprint } from 'lucide-react';

interface IdentityCardProps {
  mode: InterfaceMode;
  user: UserProfile;
}

export const IdentityCard: React.FC<IdentityCardProps> = ({ mode, user }) => {
  const isDay = mode === InterfaceMode.DAY;

  return (
    <div className={`relative overflow-hidden transition-all duration-700 ease-in-out
      ${isDay 
        ? 'bg-white rounded-2xl shadow-lg border border-slate-200 p-6 max-w-sm' 
        : 'bg-[#0B0A0F] border-2 border-purple-500/50 shadow-[0_0_30px_rgba(168,85,247,0.2)] p-6 max-w-sm clip-path-polygon'
      }`}
    >
      {/* Background Decor */}
      {!isDay && (
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-purple-500 to-transparent animate-pulse" />
      )}

      {/* Header Section */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className={`text-xs uppercase tracking-widest mb-1 transition-colors duration-500
            ${isDay ? 'text-slate-500 font-bold' : 'text-neon-purple text-purple-400 font-mono'}`}
          >
            {isDay ? 'Educational Institution' : 'THE CITADEL'}
          </h3>
          <h2 className={`text-2xl transition-colors duration-500
            ${isDay ? 'font-sans font-bold text-slate-900' : 'font-mono text-white glitch-text'}`}
            data-text={user.name}
          >
            {user.name}
          </h2>
        </div>
        <div className="w-12 h-12">
           {isDay ? (
             <img src={user.avatarUrl} alt="Profile" className="w-full h-full rounded-full object-cover border-2 border-slate-100" />
           ) : (
             <div className="w-full h-full border border-green-500 bg-black relative flex items-center justify-center overflow-hidden">
                <img src={user.avatarUrl} alt="Profile" className="w-full h-full object-cover opacity-60 grayscale mix-blend-luminosity" />
                <div className="absolute inset-0 bg-green-500/10" />
             </div>
           )}
        </div>
      </div>

      {/* ID Details */}
      <div className="space-y-4">
        <div className={`flex justify-between items-center border-b pb-2 transition-colors duration-500
          ${isDay ? 'border-slate-100' : 'border-gray-800'}`}>
          <span className={`text-sm ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
            {isDay ? 'Student ID' : 'UID::HASH'}
          </span>
          <span className={`font-medium ${isDay ? 'text-slate-700' : 'text-green-400 font-mono'}`}>
            {user.idString}
          </span>
        </div>

        <div className={`flex justify-between items-center border-b pb-2 transition-colors duration-500
          ${isDay ? 'border-slate-100' : 'border-gray-800'}`}>
          <span className={`text-sm ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
            {isDay ? 'Clearance' : 'ACCESS_LEVEL'}
          </span>
          <div className="flex items-center gap-2">
            {isDay ? <ShieldCheck size={16} className="text-blue-600" /> : <Hexagon size={16} className="text-purple-500" />}
            <span className={`font-medium ${isDay ? 'text-blue-900' : 'text-purple-400 font-mono'}`}>
              {isDay ? 'Level 4 (Authorized)' : 'ARCHITECT'}
            </span>
          </div>
        </div>
      </div>

      {/* Footer / Barcode */}
      <div className="mt-6 flex justify-between items-end">
        <div className="flex flex-col">
           <span className={`text-[10px] mb-1 ${isDay ? 'text-slate-400' : 'text-gray-600 font-mono'}`}>
             {isDay ? 'ISSUED: SEP 2024' : 'MINTED: BLOCK 992'}
           </span>
           {isDay ? <QrCode className="text-slate-800 opacity-80" size={32} /> : <Fingerprint className="text-green-500 animate-pulse" size={32} />}
        </div>
        <div className={`text-right`}>
           <div className={`text-xs font-bold px-2 py-1 rounded
             ${isDay ? 'bg-green-100 text-green-800' : 'bg-green-900/20 text-green-400 border border-green-500/30 font-mono'}`}>
             {isDay ? 'ACTIVE' : 'ONLINE'}
           </div>
        </div>
      </div>
    </div>
  );
};