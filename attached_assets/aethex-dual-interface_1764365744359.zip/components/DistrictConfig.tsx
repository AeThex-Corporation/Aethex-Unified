
import React, { useState } from 'react';
import { Save, AlertOctagon, Info } from 'lucide-react';

export const DistrictConfig: React.FC = () => {
  const [allowGenAI, setAllowGenAI] = useState(true);
  const [piiLevel, setPiiLevel] = useState('High');
  const [retention, setRetention] = useState('1 Year');

  return (
    <div className="max-w-4xl mx-auto bg-white border border-slate-200 shadow-sm rounded-lg overflow-hidden">
      {/* Header */}
      <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
        <div>
          <h2 className="text-lg font-bold text-slate-800">District Policy Configuration</h2>
          <p className="text-xs text-slate-500">Global settings for District #884 (52,000 Users)</p>
        </div>
        <div className="flex gap-2">
           <button className="px-4 py-2 bg-white border border-slate-300 text-slate-700 text-sm font-medium rounded shadow-sm hover:bg-slate-50">Cancel</button>
           <button className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded shadow-sm hover:bg-blue-700 flex items-center gap-2">
             <Save size={16}/> Save Changes
           </button>
        </div>
      </div>

      {/* Form Content */}
      <div className="p-6 space-y-8">
        
        {/* Section 1 */}
        <div className="space-y-4">
           <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide border-b border-slate-100 pb-2">Generative AI Safety</h3>
           
           <div className="flex items-center justify-between py-2">
              <div>
                 <label className="block text-sm font-medium text-slate-700">Allow Image Generation</label>
                 <p className="text-xs text-slate-500">Students can use DALL-E 3 / Imagen models.</p>
              </div>
              <button 
                onClick={() => setAllowGenAI(!allowGenAI)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${allowGenAI ? 'bg-blue-600' : 'bg-slate-200'}`}
              >
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${allowGenAI ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                 <label className="block text-sm font-medium text-slate-700 mb-1">PII Filtering Strictness</label>
                 <select 
                   value={piiLevel}
                   onChange={(e) => setPiiLevel(e.target.value)}
                   className="mt-1 block w-full rounded-md border-slate-300 py-2 pl-3 pr-10 text-base focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm border"
                 >
                    <option>Low (Warn Only)</option>
                    <option>Medium (Block SSN)</option>
                    <option>High (Block All Identifiers)</option>
                 </select>
              </div>
              <div>
                 <label className="block text-sm font-medium text-slate-700 mb-1">Chat Retention Period</label>
                 <select 
                   value={retention}
                   onChange={(e) => setRetention(e.target.value)}
                   className="mt-1 block w-full rounded-md border-slate-300 py-2 pl-3 pr-10 text-base focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm border"
                 >
                    <option>30 Days</option>
                    <option>1 Year (Recommended)</option>
                    <option>Indefinite</option>
                 </select>
              </div>
           </div>
        </div>

        {/* Danger Zone */}
        <div className="pt-6 mt-6 border-t border-slate-200">
           <h3 className="text-sm font-bold text-red-600 uppercase tracking-wide mb-4 flex items-center gap-2">
             <AlertOctagon size={16}/> Emergency Controls
           </h3>
           <div className="bg-red-50 border border-red-100 rounded-lg p-4 flex items-center justify-between">
              <div>
                 <h4 className="text-sm font-bold text-red-800">Revoke All Student Access</h4>
                 <p className="text-xs text-red-600 mt-1">Immediately terminates all active sessions and locks accounts. Use only during security breaches.</p>
              </div>
              <button className="bg-white border border-red-200 text-red-600 hover:bg-red-600 hover:text-white px-4 py-2 rounded text-sm font-bold transition-colors shadow-sm">
                 REVOKE ACCESS
              </button>
           </div>
        </div>

      </div>
    </div>
  );
};
