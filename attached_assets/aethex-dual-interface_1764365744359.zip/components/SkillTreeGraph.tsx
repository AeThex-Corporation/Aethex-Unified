import React from 'react';
import { DualEvent } from '../types';
import { Lock, Zap, ShieldAlert, Hexagon } from 'lucide-react';

interface SkillTreeGraphProps {
  events: DualEvent[];
}

export const SkillTreeGraph: React.FC<SkillTreeGraphProps> = ({ events }) => {
  // Simple grouping by tier for visualization columns
  const tier1 = events.filter(e => e.gamification.tier === 'TIER_1');
  const tier2 = events.filter(e => e.gamification.tier === 'TIER_2');
  const tier3 = events.filter(e => e.gamification.tier === 'TIER_3');

  return (
    <div className="bg-[#0B0A0F] rounded-xl border border-gray-800 relative overflow-hidden h-full flex flex-col">
      {/* Matrix Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" 
           style={{ 
             backgroundImage: 'radial-gradient(circle, #22c55e 1px, transparent 1px)', 
             backgroundSize: '30px 30px' 
           }} 
      />

      {/* Header */}
      <div className="p-4 border-b border-green-900/30 flex justify-between items-end bg-black/40 backdrop-blur-sm z-10">
        <div>
           <h3 className="font-mono font-bold text-green-400 text-lg flex items-center gap-2">
             <Hexagon size={20} className="animate-pulse"/>
             NEURAL_MASTERY_WEB
           </h3>
           <p className="text-xs text-purple-400 font-mono">v.4.0.1 [SYNCED]</p>
        </div>
        <div className="text-right font-mono">
          <div className="text-xs text-gray-500">TOTAL XP</div>
          <div className="text-xl text-white font-bold">
            {events.reduce((acc, curr) => acc + (curr.gamification.isUnlocked ? curr.gamification.xp : 0), 0)}
          </div>
        </div>
      </div>

      {/* Graph Container */}
      <div className="flex-1 relative overflow-y-auto p-8 flex justify-center gap-12 md:gap-24 items-center z-0">
        
        {/* SVG Connector Lines Layer (Simple absolute positioning simulation) */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-30">
             <svg width="100%" height="100%" className="stroke-green-500 stroke-2">
                {/* This is a decorative simplification of connections */}
                <line x1="20%" y1="50%" x2="50%" y2="30%" />
                <line x1="20%" y1="50%" x2="50%" y2="70%" />
                <line x1="50%" y1="30%" x2="80%" y2="50%" />
                <line x1="50%" y1="70%" x2="80%" y2="50%" />
             </svg>
        </div>

        {/* Columns */}
        <Column title="INITIATE" events={tier1} delay={0} />
        <Column title="ADEPT" events={tier2} delay={150} />
        <Column title="VANGUARD" events={tier3} delay={300} />

      </div>
    </div>
  );
};

interface ColumnProps {
  title: string;
  events: DualEvent[];
  delay: number;
}

const Column: React.FC<ColumnProps> = ({ title, events, delay }) => (
  <div className="flex flex-col gap-8 items-center z-10 relative">
    <h4 className="text-[10px] text-gray-500 tracking-[0.2em] font-mono mb-2 border-b border-gray-800 pb-1">{title}</h4>
    {events.map((e, i) => (
      <Node key={e.id} event={e} index={i} delay={delay} />
    ))}
  </div>
);

interface NodeProps {
  event: DualEvent;
  index: number;
  delay: number;
}

const Node: React.FC<NodeProps> = ({ event, index, delay }) => {
  const { isUnlocked, type, skillName, xp } = event.gamification;
  const isFailure = type === 'QUEST' && !isUnlocked; // Locked due to failure

  return (
    <div 
      className={`group relative w-24 h-24 md:w-32 md:h-32 flex flex-col items-center justify-center p-2 text-center border transition-all duration-500 cursor-pointer
      ${isUnlocked 
        ? 'border-green-500 bg-green-900/10 shadow-[0_0_15px_rgba(34,197,94,0.3)] hover:scale-110 hover:bg-green-900/30' 
        : isFailure 
          ? 'border-red-500/50 bg-red-900/10 grayscale-[0.5]' 
          : 'border-gray-800 bg-black grayscale opacity-50'
      } clip-path-hexagon`}
      style={{ animationDelay: `${delay + (index * 100)}ms` }}
    >
      {/* Icon */}
      <div className={`mb-1 ${isUnlocked ? 'text-green-400' : isFailure ? 'text-red-500' : 'text-gray-600'}`}>
        {isUnlocked ? <Zap size={24} /> : isFailure ? <ShieldAlert size={24} /> : <Lock size={24} />}
      </div>
      
      {/* Text */}
      <div className="text-[9px] md:text-[10px] font-mono leading-tight text-white">
        {skillName}
      </div>
      
      {/* XP Tag */}
      <div className={`mt-1 text-[8px] px-1 rounded border
        ${isUnlocked 
          ? 'border-green-500 text-green-400 bg-green-900/40' 
          : 'border-gray-700 text-gray-500'}`}>
        {xp} XP
      </div>

      {/* Hover Detail Card */}
      <div className="absolute bottom-full mb-2 w-48 bg-black border border-green-500 p-3 hidden group-hover:block z-50 shadow-[0_0_20px_rgba(0,0,0,0.9)]">
         <h5 className="text-green-400 font-bold text-xs mb-1">{event.rawEvent}</h5>
         <p className="text-[10px] text-gray-400 font-mono">
           NODE_ID: {event.gamification.skillNodeId}<br/>
           STATUS: {isUnlocked ? 'COMPILED' : 'RUNTIME_ERROR'}
         </p>
      </div>
    </div>
  );
};