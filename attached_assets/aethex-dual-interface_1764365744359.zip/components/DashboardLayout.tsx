import React from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { useTheme } from '../context/ThemeContext';
import { InterfaceMode } from '../types';

interface DashboardLayoutProps {
  onLogout: () => void;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ onLogout }) => {
  const { mode } = useTheme();
  const isDay = mode === InterfaceMode.DAY;

  return (
    <div className={`flex h-screen w-screen overflow-hidden transition-colors duration-700
      ${isDay ? 'bg-slate-50 text-slate-900 font-sans' : 'bg-black text-gray-300 font-mono'}`}
    >
      {/* Dynamic Sidebar */}
      <Sidebar onLogout={onLogout} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full relative overflow-hidden">
        
        {/* Night Mode Grid Background */}
        {!isDay && (
          <div className="absolute inset-0 z-0 pointer-events-none opacity-20" 
               style={{ 
                 backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)', 
                 backgroundSize: '40px 40px' 
               }} 
          />
        )}

        {/* Content Rendered by Router */}
        <main className="flex-1 overflow-y-auto relative z-10">
          <Outlet />
        </main>
      </div>
    </div>
  );
};