
import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { InterfaceMode, AuditLogEntry } from '../types';
import { AUDIT_LOGS } from '../services/mockData';
import { ShieldAlert, CheckCircle, AlertTriangle, Search, Filter, Lock, X, Clock, User, Activity, Shield, EyeOff, FileJson, ChevronRight, BarChart3 } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Mock Trend Data for the Chart
const TREND_DATA = [
  { time: '08:00', allowed: 45, blocked: 2, flagged: 5 },
  { time: '09:00', allowed: 120, blocked: 8, flagged: 12 },
  { time: '10:00', allowed: 160, blocked: 15, flagged: 8 },
  { time: '11:00', allowed: 140, blocked: 5, flagged: 20 },
  { time: '12:00', allowed: 80, blocked: 1, flagged: 4 },
  { time: '13:00', allowed: 190, blocked: 12, flagged: 15 },
  { time: '14:00', allowed: 210, blocked: 22, flagged: 10 },
];

export const ComplianceLog: React.FC = () => {
  const { mode } = useTheme();
  const isDay = mode === InterfaceMode.DAY;
  
  const [logs, setLogs] = useState<AuditLogEntry[]>(AUDIT_LOGS);
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null);

  const handleStatusUpdate = (newStatus: 'ALLOWED' | 'QUARANTINED') => {
    if (!selectedLog) return;
    const updatedLog: AuditLogEntry = {
      ...selectedLog,
      status: newStatus,
      flagged: newStatus === 'ALLOWED' ? false : selectedLog.flagged
    };
    setLogs(prev => prev.map(l => l.id === selectedLog.id ? updatedLog : l));
    setSelectedLog(updatedLog);
  };

  return (
    <div className="container mx-auto px-4 py-6 h-full flex flex-col gap-6">
      <header>
        <h1 className={`text-2xl font-bold transition-colors duration-500 mb-2
          ${isDay ? 'text-slate-900' : 'text-white font-mono'}`}>
          {isDay ? 'Compliance Audit Logs' : 'PACKET_STREAM_MONITOR'}
        </h1>
        <p className={`text-sm ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
          {isDay ? 'Review system flags, blocked attempts, and user activity.' : 'Intercepting traffic on Port 8080...'}
        </p>
      </header>

      {/* NEW: Analytics Chart Section (Adds Enterprise Legitimacy) */}
      <div className={`h-64 w-full rounded-xl border p-4 transition-all
        ${isDay ? 'bg-white border-slate-200 shadow-sm' : 'bg-black border-green-900/30'}`}>
         <div className="flex items-center gap-2 mb-4">
            <BarChart3 size={16} className={isDay ? 'text-slate-500' : 'text-green-500'} />
            <h3 className={`text-sm font-bold uppercase tracking-wider ${isDay ? 'text-slate-600' : 'text-green-400 font-mono'}`}>
              {isDay ? 'Traffic Analysis (24h)' : 'NET_TRAFFIC_VOLUME'}
            </h3>
         </div>
         <div className="w-full h-[80%]">
           <ResponsiveContainer width="100%" height="100%">
             <AreaChart data={TREND_DATA}>
               <defs>
                 <linearGradient id="colorAllowed" x1="0" y1="0" x2="0" y2="1">
                   <stop offset="5%" stopColor={isDay ? "#3b82f6" : "#22c55e"} stopOpacity={0.1}/>
                   <stop offset="95%" stopColor={isDay ? "#3b82f6" : "#22c55e"} stopOpacity={0}/>
                 </linearGradient>
                 <linearGradient id="colorBlocked" x1="0" y1="0" x2="0" y2="1">
                   <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                   <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                 </linearGradient>
               </defs>
               <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDay ? "#e2e8f0" : "#1f2937"} />
               <XAxis 
                 dataKey="time" 
                 axisLine={false} 
                 tickLine={false} 
                 tick={{fill: isDay ? '#94a3b8' : '#4ade80', fontSize: 10, fontFamily: isDay ? 'Inter' : 'Space Mono'}} 
               />
               <YAxis 
                 axisLine={false} 
                 tickLine={false} 
                 tick={{fill: isDay ? '#94a3b8' : '#4ade80', fontSize: 10, fontFamily: isDay ? 'Inter' : 'Space Mono'}} 
               />
               <Tooltip 
                  contentStyle={{
                    backgroundColor: isDay ? '#fff' : '#000',
                    borderColor: isDay ? '#e2e8f0' : '#22c55e',
                    color: isDay ? '#000' : '#22c55e',
                    fontFamily: isDay ? 'Inter' : 'Space Mono',
                    fontSize: '12px'
                  }}
               />
               <Area type="monotone" dataKey="allowed" stroke={isDay ? "#3b82f6" : "#22c55e"} fillOpacity={1} fill="url(#colorAllowed)" strokeWidth={2} />
               <Area type="monotone" dataKey="blocked" stroke="#ef4444" fillOpacity={1} fill="url(#colorBlocked)" strokeWidth={2} />
             </AreaChart>
           </ResponsiveContainer>
         </div>
      </div>

      {/* Existing Log Table */}
      <div className={`flex-1 rounded-xl border overflow-hidden flex flex-col transition-all min-h-[400px]
        ${isDay ? 'bg-white border-slate-200 shadow-sm' : 'bg-black border-green-900/30'}`}>
        
        {/* Toolbar */}
        <div className={`p-4 border-b flex justify-between items-center
          ${isDay ? 'bg-slate-50 border-slate-200' : 'bg-black border-gray-800'}`}>
           
           <div className="flex gap-3">
             <div className={`flex items-center gap-2 px-3 py-1.5 border rounded-md text-sm
               ${isDay ? 'bg-white border-slate-300 text-slate-500' : 'bg-black border-green-500/30 text-green-500 font-mono'}`}>
               <Search size={14} />
               <span>{isDay ? 'Search logs...' : 'GREP_PATTERN'}</span>
             </div>
             <button className={`flex items-center gap-2 px-3 py-1.5 border rounded-md text-sm
               ${isDay ? 'bg-white border-slate-300 text-slate-700' : 'bg-black border-gray-700 text-gray-400 font-mono'}`}>
               <Filter size={14} />
               {isDay ? 'Filter: All Events' : 'MASK: ALL'}
             </button>
           </div>

           <div className={`text-xs font-bold px-2 py-1 rounded border
             ${isDay ? 'bg-blue-50 text-blue-700 border-blue-100' : 'bg-red-900/20 text-red-500 border-red-900'}`}>
             {isDay ? 'Export Report (PDF)' : 'DUMP_HASHES'}
           </div>
        </div>

        {/* Table / Stream */}
        <div className="flex-1 overflow-auto">
          <table className="w-full text-left text-sm">
            <thead className={`sticky top-0 z-10
              ${isDay ? 'bg-slate-50 text-slate-500 border-b border-slate-200' : 'bg-black text-green-600 font-mono border-b border-gray-800'}`}>
              <tr>
                <th className="px-6 py-3 font-semibold">Timestamp</th>
                <th className="px-6 py-3 font-semibold">User ID</th>
                <th className="px-6 py-3 font-semibold">Action</th>
                <th className="px-6 py-3 font-semibold">Flagged?</th>
                <th className="px-6 py-3 font-semibold">Trigger</th>
                <th className="px-6 py-3 font-semibold">Status</th>
                <th className="px-6 py-3 font-semibold"></th>
              </tr>
            </thead>
            <tbody className={`divide-y ${isDay ? 'divide-slate-100' : 'divide-gray-900'}`}>
              {logs.map((log) => (
                <tr 
                  key={log.id} 
                  onClick={() => setSelectedLog(log)}
                  className={`group transition-colors cursor-pointer
                  ${isDay ? 'hover:bg-blue-50/50' : 'hover:bg-green-900/10 font-mono text-gray-400'}`}
                >
                  
                  <td className={`px-6 py-3 whitespace-nowrap ${isDay ? 'text-slate-500' : 'text-gray-600'}`}>
                    {log.timestamp}
                  </td>
                  
                  <td className={`px-6 py-3 font-medium ${isDay ? 'text-slate-700' : 'text-purple-400'}`}>
                    {isDay ? log.userId : `0x${log.userId.split('-')[1] || 'UNK'}...`}
                  </td>
                  
                  <td className="px-6 py-3">
                    {log.action}
                  </td>
                  
                  <td className="px-6 py-3">
                    {log.flagged ? (
                       <span className={`flex items-center gap-1 font-bold ${isDay ? 'text-red-600' : 'text-red-500'}`}>
                         <AlertTriangle size={14}/> YES
                       </span>
                    ) : (
                       <span className={`flex items-center gap-1 ${isDay ? 'text-slate-400' : 'text-gray-700'}`}>
                         NO
                       </span>
                    )}
                  </td>
                  
                  <td className={`px-6 py-3 ${log.flagged ? (isDay ? 'text-slate-900' : 'text-white') : 'text-slate-400 opacity-50'}`}>
                    {log.trigger}
                  </td>
                  
                  <td className="px-6 py-3">
                     {log.status === 'BLOCKED' && (
                       <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold
                         ${isDay ? 'bg-red-100 text-red-700 border border-red-200' : 'bg-red-900/30 text-red-400 border border-red-500/50'}`}>
                         <ShieldAlert size={12} /> BLOCKED
                       </span>
                     )}
                     {log.status === 'FLAGGED' && (
                       <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold
                         ${isDay ? 'bg-amber-100 text-amber-700 border border-amber-200' : 'bg-amber-900/30 text-amber-400 border border-amber-500/50'}`}>
                         <AlertTriangle size={12} /> FLAGGED
                       </span>
                     )}
                     {log.status === 'ALLOWED' && (
                       <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold
                         ${isDay ? 'bg-green-100 text-green-700 border border-green-200' : 'text-green-600'}`}>
                         <CheckCircle size={12} /> ALLOWED
                       </span>
                     )}
                     {log.status === 'QUARANTINED' && (
                       <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold
                         ${isDay ? 'bg-purple-100 text-purple-700 border border-purple-200' : 'bg-purple-900/30 text-purple-400 border border-purple-500/50'}`}>
                         <Lock size={12} /> HELD
                       </span>
                     )}
                  </td>
                  <td className="px-6 py-3 text-right">
                     <ChevronRight size={16} className={`opacity-0 group-hover:opacity-100 transition-opacity ${isDay ? 'text-slate-400' : 'text-green-500'}`} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className={`w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] transition-all
             ${isDay ? 'bg-white' : 'bg-black border border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.2)]'}`}>
             
             {/* Modal Header */}
             <div className={`p-6 border-b flex justify-between items-center
               ${isDay ? 'bg-slate-50 border-slate-100' : 'bg-gray-900 border-green-900/30'}`}>
               <div>
                 <h2 className={`text-xl font-bold ${isDay ? 'text-slate-900' : 'text-green-400 font-mono'}`}>
                   {isDay ? 'Audit Log Details' : 'EVENT_PACKET_INSPECTOR'}
                 </h2>
                 <p className={`text-sm ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
                   ID: {selectedLog.id}
                 </p>
               </div>
               <button 
                 onClick={() => setSelectedLog(null)}
                 className={`p-2 rounded-full transition-colors
                   ${isDay ? 'hover:bg-slate-200 text-slate-500' : 'hover:bg-green-900/20 text-green-500'}`}
               >
                 <X size={24} />
               </button>
             </div>

             {/* Modal Body */}
             <div className="p-6 overflow-y-auto space-y-6">
                
                {/* Status Badge Large */}
                <div className="flex items-center gap-4">
                   <div className={`p-3 rounded-full ${
                     selectedLog.status === 'BLOCKED' ? (isDay ? 'bg-red-100 text-red-600' : 'bg-red-900/20 text-red-500') :
                     selectedLog.status === 'FLAGGED' ? (isDay ? 'bg-amber-100 text-amber-600' : 'bg-amber-900/20 text-amber-500') :
                     selectedLog.status === 'QUARANTINED' ? (isDay ? 'bg-purple-100 text-purple-600' : 'bg-purple-900/20 text-purple-500') :
                     (isDay ? 'bg-green-100 text-green-600' : 'bg-green-900/20 text-green-500')
                   }`}>
                      {selectedLog.status === 'BLOCKED' && <ShieldAlert size={32} />}
                      {selectedLog.status === 'FLAGGED' && <AlertTriangle size={32} />}
                      {selectedLog.status === 'QUARANTINED' && <Lock size={32} />}
                      {selectedLog.status === 'ALLOWED' && <CheckCircle size={32} />}
                   </div>
                   <div>
                      <div className={`text-sm font-bold uppercase tracking-wider ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>Event Status</div>
                      <div className={`text-2xl font-bold ${
                        selectedLog.status === 'BLOCKED' ? (isDay ? 'text-red-700' : 'text-red-500') :
                        selectedLog.status === 'FLAGGED' ? (isDay ? 'text-amber-700' : 'text-amber-500') :
                        selectedLog.status === 'QUARANTINED' ? (isDay ? 'text-purple-700' : 'text-purple-500') :
                        (isDay ? 'text-green-700' : 'text-green-500')
                      } ${!isDay && 'font-mono'}`}>
                        {selectedLog.status}
                      </div>
                   </div>
                </div>

                {/* Redacted Info Section (if flagged) */}
                {(selectedLog.flagged || selectedLog.trigger.includes('PII')) && (
                   <div className={`rounded-lg p-4 border ${isDay ? 'bg-red-50 border-red-100' : 'bg-red-900/10 border-red-500/30'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <EyeOff size={16} className={isDay ? 'text-red-600' : 'text-red-400'} />
                        <span className={`text-sm font-bold ${isDay ? 'text-red-800' : 'text-red-400 font-mono'}`}>
                          {isDay ? 'Redacted Content Preview' : 'DATA_PACKET_SANITIZED'}
                        </span>
                      </div>
                      <div className={`text-sm font-mono p-3 rounded ${isDay ? 'bg-white border border-red-100 text-slate-600' : 'bg-black border border-red-900/50 text-gray-400'}`}>
                         User input: "My password is <span className="bg-slate-800 text-transparent select-none rounded px-1">hunter2</span> and I live at <span className="bg-slate-800 text-transparent select-none rounded px-1">123 Main St</span>."
                      </div>
                      <p className={`text-[10px] mt-2 ${isDay ? 'text-red-600' : 'text-red-500'}`}>
                        * Sensitive patterns automatically masked before storage.
                      </p>
                   </div>
                )}

                {/* Grid Details */}
                <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 p-6 rounded-xl
                  ${isDay ? 'bg-slate-50 border border-slate-100' : 'bg-gray-900/20 border border-green-900/30'}`}>
                   
                   <DetailItem label="Timestamp" value={selectedLog.timestamp} icon={<Clock size={16} />} mode={mode} />
                   <DetailItem label="User Identity" value={selectedLog.userId} icon={<User size={16} />} mode={mode} />
                   <DetailItem label="Action Type" value={selectedLog.action} icon={<Activity size={16} />} mode={mode} />
                   <DetailItem label="Security Trigger" value={selectedLog.trigger} icon={<Shield size={16} />} mode={mode} />
                   
                </div>

                {/* Raw Data / Context */}
                 <div>
                    <h3 className={`text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2 ${isDay ? 'text-slate-700' : 'text-green-400 font-mono'}`}>
                      <FileJson size={16} />
                      {isDay ? 'Full Log Entry' : 'RAW_JSON_PAYLOAD'}
                    </h3>
                    <div className={`p-4 rounded-lg font-mono text-xs overflow-x-auto border
                      ${isDay ? 'bg-slate-900 text-blue-100 border-slate-800' : 'bg-black border-green-900 text-green-500'}`}>
                      <pre>{JSON.stringify(selectedLog, null, 2)}</pre>
                    </div>
                 </div>

             </div>

             {/* Modal Footer with Actions */}
             <div className={`p-4 border-t flex justify-end gap-3
                ${isDay ? 'bg-slate-50 border-slate-100' : 'bg-gray-900 border-green-900/30'}`}>
                
                <button 
                  onClick={() => setSelectedLog(null)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors
                    ${isDay ? 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50' : 'border border-green-500/30 text-green-500 hover:bg-green-900/20 font-mono'}`}
                >
                  Close
                </button>

                {(selectedLog.flagged || selectedLog.status === 'BLOCKED' || selectedLog.status === 'QUARANTINED') && (
                  <>
                     {selectedLog.status !== 'ALLOWED' && (
                        <button 
                           onClick={() => handleStatusUpdate('ALLOWED')}
                           className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2
                             ${isDay ? 'bg-green-50 text-green-700 border border-green-200 hover:bg-green-100' : 'bg-green-900/20 text-green-400 border border-green-500/50 hover:bg-green-900/40 font-mono'}`}
                        >
                           <CheckCircle size={16} />
                           {isDay ? 'Allow Action' : 'OVERRIDE_LOCK'}
                        </button>
                     )}
                     
                     {selectedLog.status !== 'QUARANTINED' && (
                        <button 
                           onClick={() => handleStatusUpdate('QUARANTINED')}
                           className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2
                             ${isDay 
                               ? 'bg-red-600 text-white hover:bg-red-700 shadow-sm' 
                               : 'bg-red-900/20 text-red-400 border border-red-500/50 hover:bg-red-900/40 font-mono'}`}
                        >
                           <Lock size={16} />
                           {isDay ? 'Quarantine User' : 'ISOLATE_ID'}
                        </button>
                     )}
                  </>
                )}
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

const DetailItem = ({ label, value, icon, mode }: { label: string, value: string, icon: React.ReactNode, mode: InterfaceMode }) => {
   const isDay = mode === InterfaceMode.DAY;
   return (
     <div>
       <div className={`flex items-center gap-2 text-xs uppercase font-bold mb-1 ${isDay ? 'text-slate-400' : 'text-gray-500 font-mono'}`}>
         {icon} {label}
       </div>
       <div className={`text-base font-medium ${isDay ? 'text-slate-900' : 'text-gray-200 font-mono'}`}>
         {value}
       </div>
     </div>
   )
}
