import React from 'react';
import { InterfaceMode, ActivityLogItem } from '../types';
import { FileText, Terminal, Clock, CheckCircle, Shield, Zap } from 'lucide-react';

interface ActivityFeedProps {
  mode: InterfaceMode;
  logs: ActivityLogItem[];
}

export const ActivityFeed: React.FC<ActivityFeedProps> = ({ mode, logs }) => {
  const isDay = mode === InterfaceMode.DAY;

  return (
    <div className={`h-full flex flex-col transition-all duration-700
      ${isDay ? 'bg-white rounded-xl border border-slate-200 shadow-sm' : 'bg-[#0B0A0F]/80 border border-gray-800'}`}
    >
      <div className={`p-4 border-b ${isDay ? 'border-slate-100' : 'border-gray-800'}`}>
        <h3 className={`font-bold flex items-center gap-2 
          ${isDay ? 'text-slate-800 font-sans' : 'text-green-400 font-mono uppercase'}`}>
          {isDay ? <Clock size={18} /> : <Terminal size={18} />}
          {isDay ? 'Recent Activity Log' : 'SYSTEM_EVENTS_STREAM'}
        </h3>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {logs.length === 0 && (
          <div className={`text-center py-8 ${isDay ? 'text-slate-400' : 'text-gray-600 font-mono'}`}>
            No events recorded.
          </div>
        )}
        
        {logs.map((log) => (
          <div key={log.id} className={`group flex items-start gap-3 p-3 rounded-lg transition-all
            ${isDay 
              ? 'hover:bg-slate-50 border border-transparent hover:border-slate-100' 
              : 'hover:bg-white/5 border border-gray-900 hover:border-green-500/30'
            }`}
          >
            {/* Icon Column */}
            <div className={`mt-1 p-2 rounded-full flex-shrink-0
              ${isDay ? 'bg-blue-50 text-blue-600' : 'bg-purple-900/20 text-purple-400'}`}>
              {isDay ? <FileText size={16} /> : <Zap size={16} />}
            </div>

            {/* Content Column */}
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-start">
                <p className={`font-medium truncate
                  ${isDay ? 'text-slate-900' : 'text-gray-200 font-mono text-sm'}`}>
                  {/* Day Mode: "Completed Python Module" / Night Mode: "Quest: Python Module [COMPLETED]" */}
                  {isDay ? `${log.action}: ${log.context}` : `EXEC::${log.action.toUpperCase()} [${log.context}]`}
                </p>
                <span className={`text-xs whitespace-nowrap ml-2
                  ${isDay ? 'text-slate-400' : 'text-green-600 font-mono'}`}>
                  {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>

              <div className="mt-1 flex items-center gap-4">
                {/* Metadata Display */}
                <span className={`text-xs flex items-center gap-1
                  ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
                  {isDay ? (
                    <>
                      <Shield size={12} /> Verified
                    </>
                  ) : (
                    <>
                      XP: +{log.metadata.score || 10}
                    </>
                  )}
                </span>
                
                <span className={`text-xs
                  ${isDay ? 'text-slate-400' : 'text-gray-600 font-mono'}`}>
                   {isDay ? `Duration: ${log.metadata.duration || 'N/A'}` : `LATENCY: ${Math.floor(Math.random() * 50)}ms`}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};