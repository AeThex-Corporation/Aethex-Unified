
import React from 'react';
import { Hexagon, Share2, ExternalLink, CheckCircle } from 'lucide-react';
import { UserProfile } from '../types';

interface PassportProfileProps {
  user: UserProfile;
}

export const PassportProfile: React.FC<PassportProfileProps> = ({ user }) => {
  const skills = [
    { name: 'React', level: 90 },
    { name: 'Python', level: 85 },
    { name: 'Node.js', level: 70 },
    { name: 'Blender', level: 60 },
    { name: 'Rust', level: 40 },
    { name: 'Solidity', level: 30 },
  ];

  return (
    <div className="bg-[#050505] min-h-full text-white font-mono overflow-y-auto pb-20 relative">
       {/* Glitch Banner */}
       <div className="h-48 w-full relative overflow-hidden bg-gray-900">
          <div className="absolute inset-0 opacity-50" 
               style={{
                   backgroundImage: 'url(https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2670&auto=format&fit=crop)',
                   backgroundSize: 'cover',
                   backgroundPosition: 'center',
                   filter: 'hue-rotate(90deg) contrast(1.2)'
               }} 
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#050505]" />
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 via-green-500 to-purple-500" />
       </div>

       <div className="max-w-4xl mx-auto px-6 relative -mt-16 z-10">
          
          {/* Header Profile */}
          <div className="flex flex-col md:flex-row items-end md:items-center gap-6 mb-12">
             <div className="relative">
                <div className="w-32 h-32 rounded-full border-4 border-black p-1 bg-black relative z-10">
                   <img src={user.avatarUrl} alt="Avatar" className="w-full h-full rounded-full object-cover grayscale hover:grayscale-0 transition-all duration-500" />
                </div>
                {/* Level Ring */}
                <div className="absolute -inset-1 rounded-full border-2 border-dashed border-green-500/50 animate-[spin_10s_linear_infinite]" />
                <div className="absolute -bottom-2 -right-2 bg-green-600 text-black font-bold px-3 py-1 text-xs rounded clip-path-polygon">
                   LVL 40
                </div>
             </div>

             <div className="flex-1 mb-2">
                <h1 className="text-4xl font-bold glitch-text mb-2" data-text={user.name}>{user.name}</h1>
                <div className="flex flex-wrap gap-4 text-sm text-gray-400">
                   <span className="flex items-center gap-1">
                      <Hexagon size={14} className="text-purple-500" />
                      Full Stack Architect
                   </span>
                   <span className="flex items-center gap-1">
                      <CheckCircle size={14} className="text-green-500" />
                      Verified Human
                   </span>
                   <span className="text-gray-600">
                      UID: {user.idString}
                   </span>
                </div>
             </div>

             <button className="flex items-center gap-2 bg-white text-black px-6 py-3 font-bold hover:bg-green-400 transition-colors clip-path-polygon">
                HIRE_ME <ExternalLink size={16}/>
             </button>
          </div>

          {/* Hex Grid Skills */}
          <div className="mb-16">
             <h3 className="text-gray-500 text-xs tracking-[0.3em] mb-6 border-b border-gray-800 pb-2">SKILL_MATRIX</h3>
             <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                {skills.map((skill) => (
                   <div key={skill.name} className="relative w-24 h-28 md:w-32 md:h-36 group">
                      <div className="absolute inset-0 bg-gray-900 clip-path-hexagon transition-all duration-300 group-hover:bg-gray-800 border border-transparent group-hover:border-green-500/50 flex flex-col items-center justify-center p-2">
                         <div className="text-2xl font-bold text-gray-700 group-hover:text-green-400 mb-1 transition-colors">
                            {skill.name.substring(0,2).toUpperCase()}
                         </div>
                         <div className="text-[10px] text-gray-500 group-hover:text-white">
                            {skill.name}
                         </div>
                         <div className="mt-2 w-12 h-1 bg-gray-800 rounded-full overflow-hidden">
                            <div className="h-full bg-purple-600" style={{ width: `${skill.level}%` }} />
                         </div>
                      </div>
                   </div>
                ))}
             </div>
          </div>

          {/* Verified Blocks */}
          <div>
             <h3 className="text-gray-500 text-xs tracking-[0.3em] mb-6 border-b border-gray-800 pb-2">IMMUTABLE_RECORDS</h3>
             <div className="space-y-3">
                {[1,2,3].map((i) => (
                   <div key={i} className="flex items-center gap-4 p-4 border border-gray-800 bg-white/5 hover:bg-white/10 transition-colors group cursor-pointer">
                      <div className="p-2 bg-purple-900/20 text-purple-400 rounded">
                         <Share2 size={20} />
                      </div>
                      <div className="flex-1">
                         <div className="flex justify-between items-center mb-1">
                            <span className="text-sm text-gray-200 group-hover:text-green-400 transition-colors">Graduation Event: High School Diploma</span>
                            <span className="text-[10px] text-gray-600">BLOCK #{90000 + i}</span>
                         </div>
                         <div className="text-[10px] font-mono text-gray-600 truncate">
                            0x71C7656EC7ab88b098defB751B7401B5f6d8976F
                         </div>
                      </div>
                   </div>
                ))}
             </div>
          </div>

       </div>
    </div>
  );
};
