import React, { useState, useEffect, useRef } from 'react';
import { Lock, Unlock, X, Database, ShieldCheck, Award } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { InterfaceMode } from '../types';

interface ClaimIdentityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ClaimIdentityModal: React.FC<ClaimIdentityModalProps> = ({ isOpen, onClose }) => {
  const { setMode } = useTheme();
  const [progress, setProgress] = useState(0);
  const [isHolding, setIsHolding] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(false);
  
  // Refs for animation frame management
  const animationFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  // Reset state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      setProgress(0);
      setIsHolding(false);
      setIsUnlocked(false);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    }
  }, [isOpen]);

  // Watch progress to trigger unlock
  useEffect(() => {
    if (progress >= 100 && !isUnlocked) {
      handleUnlock();
    }
  }, [progress, isUnlocked]);

  const animateProgress = (time: number) => {
    if (!lastTimeRef.current) lastTimeRef.current = time;
    const deltaTime = time - lastTimeRef.current;

    if (deltaTime > 16) { // Cap roughly at 60fps
      setProgress((prev) => Math.min(prev + 1.5, 100)); // Speed of fill
      lastTimeRef.current = time;
    }
    animationFrameRef.current = requestAnimationFrame(animateProgress);
  };

  const animateDrain = (time: number) => {
    if (!lastTimeRef.current) lastTimeRef.current = time;
    const deltaTime = time - lastTimeRef.current;

    if (deltaTime > 16) {
       setProgress((prev) => {
         if (prev <= 0) {
           if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
           return 0;
         }
         return Math.max(prev - 3, 0); // Speed of drain
       });
       lastTimeRef.current = time;
    }
    animationFrameRef.current = requestAnimationFrame(animateDrain);
  };

  const startHolding = () => {
    if (isUnlocked) return;
    setIsHolding(true);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    lastTimeRef.current = 0;
    animationFrameRef.current = requestAnimationFrame(animateProgress);
  };

  const stopHolding = () => {
    if (isUnlocked) return;
    setIsHolding(false);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    lastTimeRef.current = 0;
    animationFrameRef.current = requestAnimationFrame(animateDrain);
  };

  const handleUnlock = () => {
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    setIsUnlocked(true);
    
    // THE SHATTER EFFECT: Wait a moment (800ms), then switch global mode
    setTimeout(() => {
      setMode(InterfaceMode.NIGHT);
    }, 800);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm transition-opacity duration-500">
      
      {/* Card Container */}
      <div className={`relative w-full max-w-lg overflow-hidden transition-all duration-700 rounded-2xl
        ${isUnlocked 
          ? 'bg-[#0B0A0F] border-2 border-green-500 shadow-[0_0_50px_rgba(34,197,94,0.5)] scale-105 clip-path-polygon' 
          : 'bg-white shadow-2xl border border-slate-200 scale-100'
        }`}
      >
        
        {/* "Shatter" Overlay - simulates the transition visually */}
        {isUnlocked && (
           <div className="absolute inset-0 bg-white z-20 animate-[ping_0.8s_ease-out_forwards] opacity-0 pointer-events-none"></div>
        )}

        <button onClick={onClose} className={`absolute top-4 right-4 z-30 hover:opacity-80 transition-colors ${isUnlocked ? 'text-green-500' : 'text-slate-400'}`}>
          <X size={24} />
        </button>

        {/* Content Area */}
        <div className="p-8 md:p-12 flex flex-col items-center text-center relative z-10">
          
          {!isUnlocked ? (
            // --- STATE 1: LOCKED (Day Mode) ---
            <>
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-6 text-slate-600">
                <Lock size={32} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Claim Sovereign Identity</h2>
              <p className="text-slate-500 mb-8">
                Graduating? Transfer your history, badges, and reputation from the district server to your personal blockchain wallet.
              </p>
              
              {/* Hold Button */}
              <div className={`relative w-full max-w-xs mx-auto transition-transform duration-100 ${isHolding && progress > 80 ? 'translate-x-[-1px] translate-y-[1px]' : ''}`}>
                <button
                  onMouseDown={startHolding}
                  onMouseUp={stopHolding}
                  onMouseLeave={stopHolding}
                  onTouchStart={startHolding}
                  onTouchEnd={stopHolding}
                  className="w-full h-14 rounded-full bg-slate-900 text-white font-bold text-lg overflow-hidden relative isolate shadow-lg hover:shadow-xl transition-shadow active:scale-95"
                >
                  <span className="relative z-10 pointer-events-none">Hold to Unlock</span>
                  {/* Progress Fill */}
                  <div 
                    className="absolute top-0 left-0 h-full bg-blue-600 transition-all duration-75 ease-linear -z-10"
                    style={{ width: `${progress}%` }}
                  />
                </button>
                <div className={`mt-2 text-xs font-medium transition-colors ${progress > 80 ? 'text-blue-600 animate-pulse' : 'text-slate-400'}`}>
                  {progress > 0 ? `${Math.round(progress)}% Verified` : 'Press and hold to confirm'}
                </div>
              </div>
            </>
          ) : (
            // --- STATE 2: UNLOCKED (Night Mode) ---
            <div className="animate-fade-in w-full">
              <div className="w-16 h-16 bg-green-900/20 border border-green-500 rounded-full flex items-center justify-center mb-6 text-green-400 animate-pulse mx-auto">
                <Unlock size={32} />
              </div>
              <h2 className="text-2xl font-bold text-white font-mono mb-2 glitch-text tracking-widest" data-text="ACCESS GRANTED">
                ACCESS GRANTED
              </h2>
              <p className="text-green-400/80 font-mono text-sm mb-8">
                Identity decoupled from District Node #884.<br/>
                Welcome to the network, Architect.
              </p>

              {/* Stats Migration Visual */}
              <div className="w-full bg-gray-900/50 border border-gray-800 rounded-lg p-4 mb-8 space-y-3 text-left">
                <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                  <span className="text-gray-500 font-mono text-xs flex items-center gap-2"><Database size={12}/> HISTORY</span>
                  <span className="text-white font-mono text-sm">4 Years Transferred</span>
                </div>
                <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                  <span className="text-gray-500 font-mono text-xs flex items-center gap-2"><Award size={12}/> BADGES</span>
                  <span className="text-white font-mono text-sm">12 Items Minted</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-500 font-mono text-xs flex items-center gap-2"><ShieldCheck size={12}/> TRUST</span>
                  <span className="text-green-400 font-mono text-sm">Level 4 Retained</span>
                </div>
              </div>

              <button 
                onClick={onClose}
                className="w-full h-12 rounded border border-green-500 text-green-400 font-mono hover:bg-green-900/20 transition-colors uppercase tracking-widest"
              >
                ENTER_SYSTEM
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};