import React from 'react';
import { InterfaceMode, UserProfile } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, Tooltip } from 'recharts';

interface StatsPanelProps {
  mode: InterfaceMode;
  user: UserProfile;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({ mode, user }) => {
  const isDay = mode === InterfaceMode.DAY;
  
  // Shared Data visualization logic
  const data = [
    { name: 'A', value: user.trustScore },
    { name: 'B', value: 100 - user.trustScore },
  ];
  
  const activityData = [
    { name: 'Mon', value: 40 },
    { name: 'Tue', value: 70 },
    { name: 'Wed', value: 90 },
    { name: 'Thu', value: 65 },
    { name: 'Fri', value: 85 },
  ];

  const DAY_COLORS = ['#3b82f6', '#e2e8f0']; // Blue / Slate
  const NIGHT_COLORS = ['#4ade80', '#374151']; // Green / Gray

  return (
    <div className={`flex flex-col gap-4 h-full transition-all duration-700
      ${isDay ? 'text-slate-800' : 'text-green-400'}`}>
      
      {/* Primary Score Card */}
      <div className={`p-6 rounded-xl flex items-center justify-between relative overflow-hidden
        ${isDay 
          ? 'bg-white border border-slate-200 shadow-sm' 
          : 'bg-black border border-green-500/30 shadow-[0_0_15px_rgba(74,222,128,0.1)]'}`}>
        
        <div>
          <p className={`text-sm font-bold uppercase tracking-wider mb-1
            ${isDay ? 'text-slate-400' : 'text-purple-400 font-mono'}`}>
            {isDay ? 'Compliance Score' : 'REPUTATION'}
          </p>
          <h2 className={`text-4xl font-black
            ${isDay ? 'text-slate-900' : 'text-white glitch-text font-mono'}`} data-text={user.trustScore}>
            {user.trustScore}{isDay ? '%' : ' XP'}
          </h2>
          <p className={`text-xs mt-2
             ${isDay ? 'text-green-600' : 'text-gray-500'}`}>
             {isDay ? 'Top 5% Percentile (Safe)' : 'ELITE TIER [UNTOUCHABLE]'}
          </p>
        </div>

        <div className="w-24 h-24">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={isDay ? 30 : 25}
                outerRadius={isDay ? 40 : 40}
                startAngle={90}
                endAngle={-270}
                paddingAngle={isDay ? 0 : 5}
                dataKey="value"
                stroke="none"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={isDay ? DAY_COLORS[index] : NIGHT_COLORS[index]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        {/* Decorative lines for night mode */}
        {!isDay && (
             <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 border-green-500/50" />
        )}
      </div>

      {/* Secondary Chart Card */}
      <div className={`flex-1 p-6 rounded-xl flex flex-col
        ${isDay 
          ? 'bg-white border border-slate-200 shadow-sm' 
          : 'bg-[#0B0A0F] border border-purple-500/30'}`}>
          
           <p className={`text-sm font-bold uppercase tracking-wider mb-4
            ${isDay ? 'text-slate-400' : 'text-green-400 font-mono'}`}>
            {isDay ? 'Weekly Attendance' : 'NETRUN_VELOCITY'}
          </p>

          <div className="flex-1 w-full min-h-[100px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activityData}>
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: isDay ? '#94a3b8' : '#4ade80', fontSize: 10, fontFamily: isDay ? 'Inter' : 'Space Mono'}} 
                />
                <Tooltip 
                  cursor={{fill: isDay ? '#f1f5f9' : '#ffffff10'}}
                  contentStyle={{
                    backgroundColor: isDay ? '#fff' : '#000',
                    borderColor: isDay ? '#e2e8f0' : '#22c55e',
                    color: isDay ? '#000' : '#22c55e',
                    fontFamily: isDay ? 'Inter' : 'Space Mono'
                  }}
                />
                <Bar 
                  dataKey="value" 
                  radius={isDay ? [4, 4, 0, 0] : [0, 0, 0, 0]} 
                  fill={isDay ? '#3b82f6' : '#a855f7'} 
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
      </div>

    </div>
  );
};