import React from 'react';
import { useNotification, Notification } from '../context/NotificationContext';
import { useTheme } from '../context/ThemeContext';
import { InterfaceMode } from '../types';
import { X, CheckCircle, AlertTriangle, Info, ShieldAlert, Terminal, Zap } from 'lucide-react';

export const NotificationSystem: React.FC = () => {
  const { notifications, removeNotification } = useNotification();
  const { mode } = useTheme();
  const isDay = mode === InterfaceMode.DAY;

  if (notifications.length === 0) return null;

  return (
    <div className={`fixed z-[100] flex flex-col gap-3 p-4 pointer-events-none
      ${isDay ? 'top-0 right-0 w-full md:w-96' : 'bottom-0 right-0 w-full md:w-[450px]'}`}
    >
      {notifications.map((note) => (
        <div key={note.id} className="pointer-events-auto">
          {isDay ? (
            <DayNotification note={note} onClose={() => removeNotification(note.id)} />
          ) : (
            <NightNotification note={note} onClose={() => removeNotification(note.id)} />
          )}
        </div>
      ))}
    </div>
  );
};

const DayNotification: React.FC<{ note: Notification; onClose: () => void }> = ({ note, onClose }) => {
  const getIcon = () => {
    switch (note.type) {
      case 'success': return <CheckCircle className="text-green-500" size={20} />;
      case 'warning': return <AlertTriangle className="text-amber-500" size={20} />;
      case 'error': return <ShieldAlert className="text-red-500" size={20} />;
      default: return <Info className="text-blue-500" size={20} />;
    }
  };

  const getBorderColor = () => {
    switch (note.type) {
      case 'success': return 'border-green-500';
      case 'warning': return 'border-amber-500';
      case 'error': return 'border-red-500';
      default: return 'border-blue-500';
    }
  };

  return (
    <div className={`bg-white rounded-lg shadow-lg border-l-4 ${getBorderColor()} p-4 flex items-start gap-3 animate-fade-in transform transition-all hover:scale-[1.02]`}>
      <div className="mt-0.5">{getIcon()}</div>
      <div className="flex-1">
        <h4 className="font-bold text-slate-800 text-sm">{note.title}</h4>
        <p className="text-sm text-slate-600 leading-tight mt-1">{note.message}</p>
      </div>
      <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
        <X size={16} />
      </button>
    </div>
  );
};

const NightNotification: React.FC<{ note: Notification; onClose: () => void }> = ({ note, onClose }) => {
  const getIcon = () => {
    switch (note.type) {
      case 'error': return <ShieldAlert className="text-red-500" size={18} />;
      case 'success': return <Zap className="text-yellow-400" size={18} />;
      default: return <Terminal className="text-green-500" size={18} />;
    }
  };

  const getColorClass = () => {
    switch (note.type) {
      case 'error': return 'border-red-500 text-red-500 bg-red-900/10';
      case 'success': return 'border-yellow-500 text-yellow-400 bg-yellow-900/10';
      default: return 'border-green-500 text-green-500 bg-green-900/10';
    }
  };

  return (
    <div className={`relative border ${getColorClass()} p-4 font-mono clip-path-polygon animate-fade-in`}>
      {/* Glitch Decor */}
      <div className="absolute top-0 left-0 w-1 h-full bg-current opacity-50 animate-pulse" />
      
      <div className="flex items-start gap-3">
        <div className="mt-0.5 animate-pulse">{getIcon()}</div>
        <div className="flex-1">
          <div className="flex justify-between items-center mb-1 border-b border-dashed border-current/30 pb-1">
             <h4 className="font-bold text-xs uppercase tracking-widest">{note.type === 'error' ? 'CRITICAL_FAILURE' : 'SYS_EVENT_LOG'}</h4>
             <span className="text-[10px] opacity-70">{new Date().toLocaleTimeString()}</span>
          </div>
          <h5 className="font-bold text-sm mb-1 uppercase">{note.title}</h5>
          <p className="text-xs opacity-80">{note.message}</p>
        </div>
        <button onClick={onClose} className="hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>
    </div>
  );
};