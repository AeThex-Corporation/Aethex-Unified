import React, { useState, useEffect } from 'react';
import { ArrowRight, School, Cpu, ToggleLeft, ToggleRight, KeyRound } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useNotification } from '../context/NotificationContext';

interface LoginPageProps {
  onLogin: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<'school' | 'creator'>('school');
  const isSchool = mode === 'school';
  const navigate = useNavigate();
  const { addNotification } = useNotification();
  
  // Controlled inputs
  const [identifier, setIdentifier] = useState('');
  const [secret, setSecret] = useState('');

  // Clear inputs when mode changes
  useEffect(() => {
    setIdentifier('');
    setSecret('');
  }, [mode]);

  const fillDemoCredentials = () => {
    if (isSchool) {
      setIdentifier('alex.chen@district.edu');
      setSecret('secure_student_pass_2024');
    } else {
      setIdentifier('0x71C7656EC7ab88b098defB751B7401B5f6d8976F');
      setSecret('pk_live_884291AX_e7b2');
    }
  };

  const handleLogin = () => {
    if (!identifier || !secret) {
      if (isSchool) {
        addNotification('error', 'Authentication Failed', 'Please enter both District ID and Password.');
      } else {
        addNotification('error', 'KEY_MISSING', 'PRIVATE_KEY OR HASH REQUIRED FOR DECRYPTION.');
      }
      return;
    }

    onLogin();
    
    if (isSchool) {
      addNotification('success', 'Login Successful', 'Welcome back to District 884 Portal. Your session is logged.');
    } else {
      addNotification('info', 'NODE_CONNECTION', 'UPLINK ESTABLISHED. WELCOME BACK, ARCHITECT.', 3000);
    }
    
    navigate('/dashboard');
  };

  return (
    <div className={`min-h-screen w-full flex flex-col items-center justify-center p-4 transition-colors duration-700 relative overflow-hidden
      ${isSchool ? 'bg-slate-50' : 'bg-[#050505]'}`}
    >
       {/* Background Effects */}
       {!isSchool && (
        <div className="absolute inset-0 z-0 opacity-20 pointer-events-none" 
             style={{ 
               backgroundImage: 'linear-gradient(#22c55e 1px, transparent 1px), linear-gradient(90deg, #22c55e 1px, transparent 1px)', 
               backgroundSize: '40px 40px' 
             }} 
        />
      )}

      {/* Login Container */}
      <div className={`relative w-full max-w-md transition-all duration-500 z-10
        ${isSchool 
          ? 'bg-white shadow-2xl rounded-2xl border border-slate-100' 
          : 'bg-black shadow-[0_0_40px_rgba(34,197,94,0.15)] border border-green-500/30'
        }`}
      >
        
        {/* Header / Toggle Area */}
        <div className="flex justify-end p-6 pb-0">
           <button 
             onClick={() => setMode(isSchool ? 'creator' : 'school')}
             className={`flex items-center gap-2 text-xs font-medium px-3 py-1.5 rounded-full transition-all
               ${isSchool 
                 ? 'bg-slate-100 text-slate-500 hover:bg-slate-200' 
                 : 'bg-green-900/20 text-green-400 border border-green-500/30 hover:bg-green-900/40 font-mono'}`}
           >
              {isSchool ? 'Architect Login' : 'District Portal'}
              {isSchool ? <ToggleLeft size={16}/> : <ToggleRight size={16}/>}
           </button>
        </div>

        <div className="p-8 pt-4">
          {/* Branding Icon */}
          <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-all duration-500
            ${isSchool ? 'bg-blue-600 text-white shadow-blue-200' : 'bg-black border border-green-500 text-green-500 shadow-[0_0_15px_rgba(34,197,94,0.4)]'}`}>
             {isSchool ? <School size={28} /> : <Cpu size={28} />}
          </div>

          <div className="space-y-2 mb-6">
            <h1 className={`text-3xl font-bold transition-colors duration-300
              ${isSchool ? 'text-slate-900' : 'text-white font-mono tracking-tight'}`}>
              {isSchool ? 'Welcome Back' : 'INITIALIZE_SESSION'}
            </h1>
            <p className={`transition-colors duration-300
              ${isSchool ? 'text-slate-500' : 'text-gray-500 font-mono text-sm'}`}>
              {isSchool ? 'Enter your district credentials to continue.' : 'Identity verification required for node access.'}
            </p>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleLogin(); }} className="space-y-5">
            
            {/* Demo Quick Fill */}
            <div className="flex justify-center">
               <button
                 type="button"
                 onClick={fillDemoCredentials}
                 className={`text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-colors
                   ${isSchool 
                     ? 'bg-blue-50 text-blue-600 hover:bg-blue-100 border border-blue-200' 
                     : 'bg-green-900/20 text-green-400 hover:bg-green-900/30 border border-green-500/30 font-mono'}`}
               >
                 <KeyRound size={12} />
                 {isSchool ? 'Auto-fill Student Demo' : 'INJECT_TEST_KEYS'}
               </button>
            </div>

            {/* Input Fields */}
            <div className="space-y-4">
              <div className="group">
                <label className={`block text-sm font-medium mb-1.5 transition-colors
                  ${isSchool ? 'text-slate-700' : 'text-green-500/80 font-mono'}`}>
                  {isSchool ? 'District ID / Email' : 'USER_HASH'}
                </label>
                <input 
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={isSchool ? "student@district.edu" : "0x..."}
                  className={`w-full px-4 py-3 outline-none transition-all duration-300
                    ${isSchool 
                      ? 'bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-slate-900 placeholder:text-slate-400' 
                      : 'bg-black border border-gray-800 rounded-none focus:border-green-500 text-green-400 font-mono placeholder:text-gray-700'}`}
                />
              </div>

              <div className="group">
                <label className={`block text-sm font-medium mb-1.5 transition-colors
                  ${isSchool ? 'text-slate-700' : 'text-green-500/80 font-mono'}`}>
                  {isSchool ? 'Password' : 'PRIVATE_KEY'}
                </label>
                <input 
                  type="password"
                  value={secret}
                  onChange={(e) => setSecret(e.target.value)}
                  placeholder={isSchool ? "••••••••" : "****************"}
                  className={`w-full px-4 py-3 outline-none transition-all duration-300
                    ${isSchool 
                      ? 'bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-slate-900 placeholder:text-slate-400' 
                      : 'bg-black border border-gray-800 rounded-none focus:border-green-500 text-green-400 font-mono placeholder:text-gray-700'}`}
                />
              </div>
            </div>

            {/* Action Button */}
            <button 
              type="submit"
              className={`w-full py-3.5 font-bold transition-all duration-300 flex justify-center items-center gap-2 mt-4
              ${isSchool 
                ? 'bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-lg shadow-blue-600/20' 
                : 'bg-green-600/10 hover:bg-green-600/20 text-green-500 border border-green-500 rounded-none font-mono tracking-wider'}`}
            >
              {isSchool ? 'Sign In' : 'DECRYPT_WALLET'}
              <ArrowRight size={18} />
            </button>

            {/* Footer Help */}
            <div className={`text-center text-xs mt-6 transition-colors
              ${isSchool ? 'text-slate-400' : 'text-gray-600 font-mono'}`}>
              {isSchool ? 'Forgot your password? Contact IT Admin.' : 'SESSION_ID: 884-992-AX [UNSECURED]'}
            </div>

          </form>
        </div>
      </div>
    </div>
  );
};