
import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { InterfaceMode, UserProfile } from '../types';
import { SecureChat } from './SecureChat';
import { SkillTreeGraph } from './SkillTreeGraph';
import { ClaimIdentityModal } from './ClaimIdentityModal';
import { ModeToggle } from './ModeToggle';
import { ShieldCheck, Fingerprint, Users, ShieldAlert, Activity, ArrowUpRight } from 'lucide-react';

// Mock Data
import { DUAL_EVENTS_DATA } from '../services/mockData';

const SHARED_USER_DATA: UserProfile = {
  name: "Alex Chen",
  idString: "884-291-AX",
  trustScore: 98,
  role: "STUDENT",
  avatarUrl: "https://picsum.photos/200/200",
  joinDate: "2023-09-01"
};

export const DashboardView: React.FC = () => {
  const { mode, toggleMode } = useTheme();
  const isDay = mode === InterfaceMode.DAY;
  const [isClaimModalOpen, setIsClaimModalOpen] = useState(false);

  return (
    <div className="container mx-auto px-4 py-6 h-full flex flex-col gap-6">
      
      {/* Header Area */}
      <header className="flex justify-between items-end flex-shrink-0">
        <div>
          <h1 className={`text-2xl font-bold transition-colors duration-500
            ${isDay ? 'text-slate-900' : 'text-white glitch-text tracking-tighter'}`}
            data-text={isDay ? "District Overview" : "SYSTEM_ROOT_ACCESS"}
          >
            {isDay ? 'District Overview' : 'SYSTEM_ROOT_ACCESS'}
          </h1>
          <div className="flex items-center gap-2 mt-1">
             <span className={`text-xs font-bold px-2 py-0.5 rounded ${isDay ? 'bg-blue-100 text-blue-800' : 'bg-green-900 text-green-400 border border-green-500'}`}>
               {isDay ? 'LIVE MONITORING' : 'ROOT_SHELL_ACTIVE'}
             </span>
             <p className={`text-sm ${isDay ? 'text-slate-500' : 'text-purple-400'}`}>
              {isDay ? `Administrator: ${SHARED_USER_DATA.name}` : `USER::${SHARED_USER_DATA.name.toUpperCase()}`}
             </p>
          </div>
        </div>
        
        {/* Primary Actions - HIDDEN TOGGLE NOW */}
        <div className="flex gap-3">
           {/* Only show visible Claim/Action button, hide the mode switch */}
          <button 
            onClick={() => setIsClaimModalOpen(true)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all font-medium
              ${isDay 
                ? 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 shadow-sm' 
                : 'bg-green-900/20 border border-green-500 text-green-400 hover:bg-green-500/20 shadow-[0_0_15px_rgba(34,197,94,0.3)]'}`}
          >
            {isDay ? <ShieldCheck size={16} /> : <Fingerprint size={16} />}
            {isDay ? 'My Portfolio' : 'MANAGE_KEYS'}
          </button>
        </div>
      </header>

      {/* Vanity Metrics Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1: Active Students */}
        <div className={`p-6 rounded-xl border shadow-sm flex flex-col justify-between relative overflow-hidden transition-all duration-500
           ${isDay ? 'bg-white border-slate-200' : 'bg-black border-gray-800'}`}>
           <div className="flex justify-between items-start">
              <div>
                <p className={`text-xs font-bold uppercase tracking-wider ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
                  {isDay ? 'Active Students' : 'CONNECTED_NODES'}
                </p>
                <h3 className={`text-3xl font-black mt-2 ${isDay ? 'text-slate-900' : 'text-white font-mono'}`}>
                  12,405
                </h3>
              </div>
              <div className={`p-2 rounded-lg ${isDay ? 'bg-blue-50 text-blue-600' : 'bg-purple-900/20 text-purple-400'}`}>
                <Users size={20} />
              </div>
           </div>
           <div className={`mt-4 flex items-center text-xs font-medium ${isDay ? 'text-green-600' : 'text-green-400'}`}>
              <ArrowUpRight size={14} className="mr-1" />
              <span>{isDay ? '+3.2% this week' : 'NEW_CONNECTIONS: +42'}</span>
           </div>
        </div>

        {/* Metric 2: PII Incidents */}
        <div className={`p-6 rounded-xl border shadow-sm flex flex-col justify-between relative overflow-hidden transition-all duration-500
           ${isDay ? 'bg-white border-slate-200' : 'bg-black border-red-900/30'}`}>
           <div className="flex justify-between items-start">
              <div>
                <p className={`text-xs font-bold uppercase tracking-wider ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
                  {isDay ? 'PII Incidents Blocked' : 'ATTACKS_DEFLECTED'}
                </p>
                <h3 className={`text-3xl font-black mt-2 ${isDay ? 'text-red-600' : 'text-red-500 font-mono glitch-text'}`} data-text="142">
                  142
                </h3>
              </div>
              <div className={`p-2 rounded-lg ${isDay ? 'bg-red-50 text-red-600' : 'bg-red-900/20 text-red-500'}`}>
                <ShieldAlert size={20} />
              </div>
           </div>
           <div className={`mt-4 flex items-center text-xs font-medium ${isDay ? 'text-red-600' : 'text-red-400'}`}>
              <span>{isDay ? 'Action Required: 5 cases' : 'FIREWALL_LOAD: 98%'}</span>
           </div>
        </div>

        {/* Metric 3: Uptime/Score */}
        <div className={`p-6 rounded-xl border shadow-sm flex flex-col justify-between relative overflow-hidden transition-all duration-500
           ${isDay ? 'bg-white border-slate-200' : 'bg-black border-gray-800'}`}>
           <div className="flex justify-between items-start">
              <div>
                <p className={`text-xs font-bold uppercase tracking-wider ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
                  {isDay ? 'Compliance Uptime' : 'SYSTEM_INTEGRITY'}
                </p>
                <h3 className={`text-3xl font-black mt-2 ${isDay ? 'text-slate-900' : 'text-green-400 font-mono'}`}>
                  99.9%
                </h3>
              </div>
              <div className={`p-2 rounded-lg ${isDay ? 'bg-green-50 text-green-600' : 'bg-green-900/20 text-green-400'}`}>
                <Activity size={20} />
              </div>
           </div>
           <div className={`mt-4 flex items-center text-xs font-medium ${isDay ? 'text-slate-500' : 'text-gray-500'}`}>
              <span>{isDay ? 'Last audit: 2 mins ago' : 'LAST_SYNC: NOW'}</span>
           </div>
        </div>
      </div>

      {/* Main Conditional Workspace */}
      <main className="flex-1 min-h-0 relative rounded-2xl overflow-hidden border transition-colors duration-700 flex flex-col
        ${isDay ? 'border-slate-200 bg-white' : 'border-gray-800 bg-black'}">
          
          {isDay ? (
            // Day Mode: Live Classroom View
            <div className="h-full flex flex-col">
               <div className="p-4 border-b border-slate-100 bg-slate-50">
                 <h3 className="font-bold text-slate-800 text-sm">Live Classroom Session: American History (Room 302)</h3>
               </div>
               <div className="flex-1 p-4">
                 <SecureChat />
               </div>
            </div>
          ) : (
             <SkillTreeGraph events={DUAL_EVENTS_DATA} />
          )}
          
      </main>

      {/* INVISIBLE TOGGLE - Command Palette Only */}
      <ModeToggle mode={mode} onToggle={toggleMode} />
      <ClaimIdentityModal isOpen={isClaimModalOpen} onClose={() => setIsClaimModalOpen(false)} />

    </div>
  );
};
