import React, { useState, useRef, useEffect } from 'react';
import { Send, ShieldAlert, User, Bot, Lock, Eye, AlertTriangle, Terminal, Network } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useNotification } from '../context/NotificationContext';
import { InterfaceMode } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  isBlocked?: boolean;
  piiFlag?: boolean;
}

export const SecureChat: React.FC = () => {
  const { mode } = useTheme();
  const { addNotification } = useNotification();
  const isDay = mode === InterfaceMode.DAY;

  const [messages, setMessages] = useState<Message[]>([
    { id: '1', sender: 'ai', text: isDay ? 'Hello Alex. I am your educational assistant. How can I help you with your essay today?' : 'UPLINK_ESTABLISHED. NODE_READY. AWAITING_INPUT...', timestamp: new Date().toISOString() }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTeacherView, setIsTeacherView] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // PII Regex: Looks for SSN-like patterns (000-00-0000) or Phone numbers
  const piiRegex = /(\b\d{3}-\d{2}-\d{4}\b)|(\b\d{3}-\d{3}-\d{4}\b)/;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = () => {
    if (!inputText.trim()) return;

    const hasPII = piiRegex.test(inputText);

    if (hasPII) {
      // Block the message
      const blockedMsg: Message = {
        id: Date.now().toString(),
        sender: 'user',
        text: inputText, 
        timestamp: new Date().toISOString(),
        isBlocked: true,
        piiFlag: true
      };
      setMessages(prev => [...prev, blockedMsg]);
      setInputText('');
      
      // Trigger Global Notification
      if (isDay) {
        addNotification('error', 'PII Detected', 'Your message contained personal information and was blocked by District Policy #884.');
      } else {
        addNotification('error', 'DATA_LEAK_PREVENTED', 'PACKET_DROPPED. PROTOCOL_VIOLATION DETECTED IN OUTPUT STREAM.');
      }

    } else {
      // Allow message
      const userMsg: Message = {
        id: Date.now().toString(),
        sender: 'user',
        text: inputText,
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, userMsg]);
      setInputText('');
      
      // Simulate AI response
      setTimeout(() => {
        setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: isDay 
            ? "That's a great start. Remember to focus on the historical context of 1776."
            : "PACKET_RECEIVED. DECRYPTING... [SUCCESS]. DATA_FRAGMENT_STORED.",
          timestamp: new Date().toISOString()
        }]);
      }, 1000);
    }
  };

  return (
    <div className={`h-full flex flex-col max-w-5xl mx-auto w-full rounded-xl border shadow-sm overflow-hidden transition-all duration-500
      ${isDay 
        ? 'bg-white border-slate-200' 
        : 'bg-[#050505] border-green-900/30 shadow-[0_0_20px_rgba(34,197,94,0.1)]'}`}
    >
      
      {/* Header */}
      <div className={`p-4 border-b flex justify-between items-center transition-colors duration-500
        ${isDay 
          ? 'bg-slate-50 border-slate-200' 
          : 'bg-black/80 border-green-900/30'}`}>
        
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors
            ${isDay ? 'bg-blue-600 text-white' : 'bg-green-900/20 text-green-400 border border-green-500/50'}`}>
            {isDay ? <Bot size={20} /> : <Terminal size={18} />}
          </div>
          <div>
            <h2 className={`font-bold text-sm ${isDay ? 'text-slate-800' : 'text-green-400 font-mono'}`}>
              {isDay ? 'District AI Tutor' : 'ENCRYPTED_UPLINK_V2'}
            </h2>
            <div className={`flex items-center gap-1 text-xs ${isDay ? 'text-green-600' : 'text-gray-500 font-mono'}`}>
              {isDay ? <Lock size={10} /> : <Network size={10} />}
              <span>{isDay ? 'Secure Connection • FERPA Compliant' : 'P2P_TUNNEL :: [SECURE]'}</span>
            </div>
          </div>
        </div>

        {/* Teacher/Admin View Toggle */}
        <div className="flex items-center gap-3">
          <span className={`text-xs font-medium ${isDay ? 'text-slate-500' : 'text-gray-600 font-mono'}`}>
            {isDay ? 'Student View' : 'USER_MODE'}
          </span>
          <button 
            onClick={() => setIsTeacherView(!isTeacherView)}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors 
              ${isDay 
                ? (isTeacherView ? 'bg-indigo-600' : 'bg-slate-300')
                : (isTeacherView ? 'bg-purple-600 border border-purple-400' : 'bg-gray-800 border border-gray-600')}`}
          >
            <span className={`inline-block h-4 w-4 transform rounded-full transition-transform 
              ${isTeacherView ? 'translate-x-6' : 'translate-x-1'}
              ${isDay ? 'bg-white' : 'bg-black'}`} />
          </button>
          <span className={`text-xs font-medium ${isDay ? 'text-slate-500' : 'text-gray-600 font-mono'}`}>
             {isDay ? 'Teacher View' : 'OVERWATCH'}
          </span>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        
        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col relative">
          
          <div className={`flex-1 overflow-y-auto p-6 space-y-6 transition-colors
            ${isDay ? 'bg-slate-50/50' : 'bg-black'}`}
            style={!isDay ? { backgroundImage: 'radial-gradient(#111 1px, transparent 1px)', backgroundSize: '20px 20px' } : {}}
          >
            {messages.map((msg) => (
              <div key={msg.id} className={`flex w-full ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex max-w-[85%] md:max-w-[70%] gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  
                  {/* Avatar */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1 border
                    ${msg.sender === 'user' 
                      ? (isDay ? 'bg-slate-200 text-slate-600 border-transparent' : 'bg-black text-green-500 border-green-500') 
                      : (isDay ? 'bg-blue-100 text-blue-600 border-transparent' : 'bg-purple-900/20 text-purple-400 border-purple-500/30')
                    }`}>
                    {msg.sender === 'user' ? <User size={16}/> : <Bot size={16}/>}
                  </div>

                  {/* Bubble */}
                  <div className={`p-4 text-sm shadow-sm relative transition-all duration-300
                    ${isDay ? 'rounded-2xl' : 'rounded-none border'}
                    ${msg.isBlocked 
                      ? (isDay ? 'bg-red-50 border border-red-200 text-red-800 w-full' : 'bg-red-900/10 border-red-500 text-red-400 w-full font-mono')
                      : msg.sender === 'user' 
                        ? (isDay ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-green-900/10 border-green-500 text-green-400 font-mono') 
                        : (isDay ? 'bg-white border border-slate-200 text-slate-800 rounded-tl-none' : 'bg-gray-900/40 border-gray-700 text-gray-300 font-mono')
                    }`}>
                    
                    {msg.isBlocked ? (
                      <div className="flex items-start gap-2">
                         <AlertTriangle size={16} className="flex-shrink-0 mt-0.5"/>
                         <div>
                           <span className="font-bold block mb-1">{isDay ? 'Message Intercepted' : 'PACKET_INTERCEPTED'}</span>
                           <span className={`px-1 rounded font-mono text-xs ${isDay ? 'bg-red-200 text-red-900' : 'bg-red-900/50 text-red-200'}`}>
                             {msg.text.replace(piiRegex, '████-██-████')}
                           </span>
                           <div className={`mt-2 text-xs italic ${isDay ? 'text-red-600' : 'text-red-500'}`}>
                             {isDay ? 'Contains sensitive Personal Identifiable Information.' : 'SENSITIVE_DATA_PATTERN_MATCHED'}
                           </div>
                         </div>
                      </div>
                    ) : (
                      msg.text
                    )}
                    
                    <div className={`text-[10px] mt-2 text-right 
                      ${isDay 
                         ? (msg.sender === 'user' && !msg.isBlocked ? 'text-blue-100' : 'text-slate-400')
                         : 'text-gray-600 font-mono'
                      }`}>
                      {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className={`p-4 border-t ${isDay ? 'bg-white border-slate-200' : 'bg-black border-green-900/30'}`}>
            <div className="flex gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder={isDay ? "Type your essay draft here..." : "> Enter command or message..."}
                className={`flex-1 px-4 py-3 outline-none transition-all
                  ${isDay 
                    ? 'bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-slate-800 placeholder:text-slate-400' 
                    : 'bg-black border border-green-800 text-green-400 font-mono placeholder:text-green-800 focus:border-green-500'}`}
              />
              <button 
                onClick={handleSend}
                className={`p-3 transition-colors flex items-center justify-center
                  ${isDay 
                    ? 'bg-blue-600 hover:bg-blue-700 text-white rounded-lg' 
                    : 'bg-green-900/20 border border-green-500 text-green-500 hover:bg-green-500/30'}`}
              >
                <Send size={20} />
              </button>
            </div>
            <p className={`text-center text-[10px] mt-2 ${isDay ? 'text-slate-400' : 'text-gray-600 font-mono'}`}>
              {isDay ? 'All conversations are monitored for student safety. ID: 884-291-AX' : 'ENCRYPTION: AES-256 [ACTIVE]. LOGS: DISABLED.'}
            </p>
          </div>
        </div>

        {/* Teacher Sidebar (Conditional) */}
        {isTeacherView && (
          <div className={`w-80 border-l flex flex-col animate-in slide-in-from-right duration-300
            ${isDay ? 'bg-slate-50 border-slate-200' : 'bg-gray-900 border-gray-700'}`}>
            <div className={`p-4 border-b ${isDay ? 'border-slate-200' : 'border-gray-700'}`}>
               <h3 className={`font-bold text-sm ${isDay ? 'text-slate-800' : 'text-white font-mono'}`}>
                 {isDay ? 'Teacher Overwatch' : 'ADMIN_CONSOLE'}
               </h3>
            </div>
            <div className="p-4 space-y-4 overflow-y-auto">
               <div className={`p-3 rounded-lg border shadow-sm
                 ${isDay ? 'bg-white border-slate-200' : 'bg-black border-red-500/30'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-red-600 flex items-center gap-1">
                      <ShieldAlert size={12}/> {isDay ? 'PII Incident' : 'FLAG_CRITICAL'}
                    </span>
                    <span className="text-[10px] text-slate-400">Just now</span>
                  </div>
                  <p className={`text-xs mb-3 ${isDay ? 'text-slate-600' : 'text-gray-400 font-mono'}`}>
                    {isDay ? 'Student attempted to share SSN pattern.' : 'PATTERN_MATCH::SSN DETECTED IN STREAM.'}
                  </p>
                  <div className="flex gap-2">
                    <button className={`flex-1 py-1 text-xs rounded font-medium ${isDay ? 'bg-slate-100 text-slate-700' : 'bg-gray-800 text-gray-300 border border-gray-600'}`}>Log</button>
                    <button className={`flex-1 py-1 text-xs rounded font-medium border ${isDay ? 'bg-red-50 text-red-700 border-red-200' : 'bg-red-900/20 text-red-400 border-red-900'}`}>Report</button>
                  </div>
               </div>

               <div className={`p-3 rounded-lg border shadow-sm opacity-60
                 ${isDay ? 'bg-white border-slate-200' : 'bg-black border-amber-500/30'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-amber-600 flex items-center gap-1">
                      <Eye size={12}/> {isDay ? 'Topic Drift' : 'CONTEXT_SHIFT'}
                    </span>
                    <span className="text-[10px] text-slate-400">10m ago</span>
                  </div>
                  <p className={`text-xs ${isDay ? 'text-slate-600' : 'text-gray-400 font-mono'}`}>
                    {isDay ? 'Conversation strayed from "American History".' : 'TOPIC::GAMING DETECTED.'}
                  </p>
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};