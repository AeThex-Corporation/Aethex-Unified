
import React, { useState, useEffect, useRef } from 'react';
import { InterfaceMode } from '../types';
import { Terminal, Search, Lock, Zap } from 'lucide-react';
import { useNotification } from '../context/NotificationContext';

interface ModeToggleProps {
  mode: InterfaceMode;
  onToggle: () => void;
}

/**
 * REPLACED: Visual Toggle -> Hidden Command Palette
 * To access Night Mode, user must press CMD+K / CTRL+K and type 'glitch'.
 */
export const ModeToggle: React.FC<ModeToggleProps> = ({ mode, onToggle }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const { addNotification } = useNotification();
  const isDay = mode === InterfaceMode.DAY;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(prev => !prev);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setInput('');
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const command = input.toLowerCase().trim();

    if (command === 'glitch' || command === 'hack') {
      if (isDay) {
         onToggle(); // Switch to Night
         addNotification('success', 'PROTOCOL_OVERRIDE', 'Welcome to the Citadel, Architect.', 3000);
      }
      setIsOpen(false);
    } else if (command === 'exit' || command === 'day') {
      if (!isDay) {
         onToggle(); // Switch to Day
      }
      setIsOpen(false);
    } else {
      addNotification('info', 'Command Not Found', `Unknown system command: ${command}`);
    }
    setInput('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[999] flex items-start justify-center pt-[20vh] bg-black/40 backdrop-blur-sm animate-fade-in">
       <div className={`w-full max-w-lg rounded-xl shadow-2xl overflow-hidden transform transition-all
         ${isDay ? 'bg-white border border-slate-200' : 'bg-black border border-green-500 shadow-[0_0_50px_rgba(34,197,94,0.3)]'}`}>
         
         <div className={`flex items-center gap-3 px-4 py-4 border-b ${isDay ? 'border-slate-100' : 'border-gray-800'}`}>
            {isDay ? <Search className="text-slate-400" size={20} /> : <Terminal className="text-green-500 animate-pulse" size={20} />}
            <form onSubmit={handleSubmit} className="flex-1">
              <input 
                ref={inputRef}
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={isDay ? "Type a command..." : "ENTER_ROOT_KEY..."}
                className={`w-full outline-none text-lg bg-transparent
                  ${isDay ? 'text-slate-800 placeholder:text-slate-400' : 'text-green-400 placeholder:text-green-800 font-mono'}`}
              />
            </form>
            <div className={`text-xs px-2 py-1 rounded border font-mono
               ${isDay ? 'bg-slate-100 text-slate-500 border-slate-200' : 'bg-gray-900 text-gray-500 border-gray-700'}`}>
               ESC
            </div>
         </div>

         <div className={`p-2 text-xs ${isDay ? 'bg-slate-50 text-slate-400' : 'bg-black text-gray-600 font-mono'}`}>
            {isDay ? (
               <div className="px-2 py-1">Tip: Try typing <span className="font-bold text-slate-600">glitch</span> to enable Developer Mode.</div>
            ) : (
               <div className="px-2 py-1">SYSTEM_READY. Type <span className="font-bold text-green-500">exit</span> to return to surface.</div>
            )}
         </div>
       </div>
    </div>
  );
};
