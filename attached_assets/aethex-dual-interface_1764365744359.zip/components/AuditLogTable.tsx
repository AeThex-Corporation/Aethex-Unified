import React from 'react';
import { DualEvent } from '../types';
import { AlertTriangle, CheckCircle, XCircle, Download, EyeOff, FileText } from 'lucide-react';

interface AuditLogTableProps {
  events: DualEvent[];
}

export const AuditLogTable: React.FC<AuditLogTableProps> = ({ events }) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ALLOWED': return <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 border border-green-200 flex items-center gap-1 w-fit"><CheckCircle size={10}/> Allowed</span>;
      case 'BLOCKED': return <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800 border border-red-200 flex items-center gap-1 w-fit"><XCircle size={10}/> Blocked</span>;
      case 'FLAGGED': return <span className="px-2 py-1 rounded-full text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1 w-fit"><AlertTriangle size={10}/> Flagged</span>;
      default: return null;
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'HIGH': return 'text-red-600 font-bold';
      case 'MEDIUM': return 'text-amber-600 font-semibold';
      default: return 'text-slate-500';
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden h-full flex flex-col">
      {/* Toolbar */}
      <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
        <div className="flex items-center gap-2">
           <FileText className="text-slate-500" size={20} />
           <h3 className="font-bold text-slate-800">FERPA Compliance Audit Log</h3>
        </div>
        <button className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-300 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
          <Download size={14} />
          Export Report
        </button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left text-sm">
          <thead className="bg-white border-b border-slate-200 sticky top-0 z-10">
            <tr>
              <th className="px-6 py-3 font-semibold text-slate-500">Timestamp</th>
              <th className="px-6 py-3 font-semibold text-slate-500">Student ID</th>
              <th className="px-6 py-3 font-semibold text-slate-500">Action</th>
              <th className="px-6 py-3 font-semibold text-slate-500">Risk Level</th>
              <th className="px-6 py-3 font-semibold text-slate-500">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {events.map((event) => (
              <tr key={event.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-3 text-slate-500 font-mono text-xs">
                  {new Date(event.timestamp).toLocaleString()}
                </td>
                <td className="px-6 py-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-700">{event.studentId}</span>
                    {/* PII Redaction Visual */}
                    <span className="bg-slate-200 text-transparent text-[8px] rounded px-1 select-none cursor-help" title="PII Automatically Redacted">
                      REDACTED
                    </span>
                  </div>
                </td>
                <td className="px-6 py-3 text-slate-900 font-medium">
                  {event.rawEvent}
                  {event.compliance.piiDetected && (
                    <div className="flex items-center gap-1 text-[10px] text-red-500 mt-1">
                      <EyeOff size={10} /> PII DETECTED
                    </div>
                  )}
                </td>
                <td className={`px-6 py-3 ${getRiskColor(event.compliance.riskLevel)}`}>
                  {event.compliance.riskLevel}
                </td>
                <td className="px-6 py-3">
                  {getStatusBadge(event.compliance.status)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="bg-slate-50 p-2 text-center border-t border-slate-200 text-xs text-slate-400">
        Confidential Data - Educational Use Only
      </div>
    </div>
  );
};