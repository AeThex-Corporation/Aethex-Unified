
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  Lock, 
  BarChart3, 
  School, 
  ArrowRight, 
  Terminal, 
  Cpu, 
  Network, 
  Zap, 
  CheckCircle, 
  Users, 
  Globe
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const [isNight, setIsNight] = useState(false);
  const navigate = useNavigate();

  const toggleMode = () => setIsNight(!isNight);

  return (
    <div className={`min-h-screen w-full transition-colors duration-1000 ease-in-out overflow-x-hidden font-sans
      ${isNight ? 'bg-[#050505] text-gray-300 font-mono selection:bg-green-500/30' : 'bg-white text-slate-900 selection:bg-blue-100'}`}>
      
      {/* Background Grids */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {isNight ? (
          <div className="absolute inset-0 opacity-20" 
             style={{ 
               backgroundImage: 'linear-gradient(#1a1a1a 1px, transparent 1px), linear-gradient(90deg, #1a1a1a 1px, transparent 1px)', 
               backgroundSize: '40px 40px' 
             }} 
          />
        ) : (
           <div className="absolute inset-0 opacity-[0.03]" 
             style={{ 
               backgroundImage: 'radial-gradient(#475569 1px, transparent 1px)', 
               backgroundSize: '20px 20px' 
             }} 
          />
        )}
      </div>

      {/* Navbar */}
      <nav className={`sticky top-0 z-50 border-b backdrop-blur-md transition-colors duration-500
        ${isNight ? 'bg-black/80 border-green-900/30' : 'bg-white/80 border-slate-200'}`}>
        <div className="container mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg transition-all duration-500
              ${isNight ? 'bg-green-500/20 text-green-400 border border-green-500' : 'bg-blue-600 text-white'}`}>
              {isNight ? <Cpu size={24} /> : <School size={24} />}
            </div>
            <span className={`text-xl font-bold tracking-tight ${isNight ? 'text-white glitch-text' : 'text-slate-900'}`} data-text="AETHEX">
              {isNight ? 'AETHEX' : 'AeThex'}
            </span>
          </div>
          
          <div className="flex items-center gap-6">
            <button 
              onClick={() => navigate('/login')}
              className={`font-medium text-sm transition-colors ${isNight ? 'text-gray-400 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}>
              Log In
            </button>
            <button 
               onClick={() => navigate('/login')}
               className={`px-5 py-2.5 rounded-lg font-bold text-sm transition-all transform hover:scale-105
               ${isNight 
                 ? 'bg-green-600 text-black hover:bg-green-500 shadow-[0_0_20px_rgba(34,197,94,0.4)]' 
                 : 'bg-slate-900 text-white hover:bg-slate-800 shadow-lg'}`}>
               {isNight ? 'INITIALIZE_DEMO' : 'Request Demo'}
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="relative pt-20 pb-32 container mx-auto px-6">
        
        {/* The Reality Switch */}
        <div className="flex justify-center mb-16">
          <div 
            onClick={toggleMode}
            className={`relative w-64 h-16 rounded-full cursor-pointer p-1.5 transition-all duration-500 shadow-2xl border-2
            ${isNight ? 'bg-black border-green-500 shadow-green-900/20' : 'bg-slate-100 border-slate-200 shadow-slate-200'}`}
          >
             {/* The Knob */}
             <div className={`absolute top-1.5 bottom-1.5 w-[48%] rounded-full shadow-md transition-all duration-500 flex items-center justify-center z-10
               ${isNight 
                 ? 'left-[50%] bg-gray-900 border border-green-500/50 text-green-400' 
                 : 'left-[1.5%] bg-white text-blue-600'}`}>
                 {isNight ? <Terminal size={20} /> : <ShieldCheck size={20} />}
             </div>
             
             {/* Labels */}
             <div className="absolute inset-0 flex items-center justify-between px-6 text-xs font-bold uppercase tracking-wider pointer-events-none">
                <span className={`transition-opacity duration-300 ${isNight ? 'opacity-40 text-gray-500' : 'opacity-100 text-slate-400'}`}>Safe</span>
                <span className={`transition-opacity duration-300 ${isNight ? 'opacity-100 text-green-900' : 'opacity-40 text-slate-300'}`}>Free</span>
             </div>
          </div>
        </div>

        <div className="text-center max-w-4xl mx-auto space-y-8 relative z-10">
           {/* Dynamic Badge */}
           <div className="flex justify-center">
              <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest border backdrop-blur-sm transition-all duration-500
                ${isNight 
                  ? 'bg-green-900/20 border-green-500 text-green-400' 
                  : 'bg-blue-50 border-blue-200 text-blue-700'}`}>
                {isNight ? 'Protocol v2.0 :: Live' : 'Trusted by 500+ Districts'}
              </span>
           </div>

           {/* Headlines */}
           <h1 className="text-5xl md:text-7xl font-bold leading-[1.1] transition-all duration-700">
             {isNight ? (
               <span className="block">
                 <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-600 glitch-text" data-text="RECLAIM">RECLAIM</span> YOUR <br/>
                 DIGITAL <span className="text-white">SOVEREIGNTY</span>
               </span>
             ) : (
               <span className="block text-slate-900">
                 The Intelligent <br/>
                 <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Infrastructure</span> for <br/>
                 Modern Education.
               </span>
             )}
           </h1>

           <p className={`text-xl md:text-2xl max-w-2xl mx-auto leading-relaxed transition-colors duration-500
             ${isNight ? 'text-gray-400 font-mono' : 'text-slate-500'}`}>
             {isNight 
               ? 'Break free from the walled garden. Build your portfolio, earn crypto-backed credentials, and own your future identity.' 
               : 'Ensure total FERPA compliance, monitor student safety, and generate audit-ready reports with our enterprise-grade AI shield.'}
           </p>

           {/* Mock UI Preview - The "Mullet" in action */}
           <div className="mt-20 relative mx-auto max-w-5xl perspective-1000 group">
              <div className={`relative rounded-xl overflow-hidden border-4 shadow-2xl transition-all duration-700 transform group-hover:scale-[1.01]
                ${isNight 
                  ? 'bg-black border-green-500/50 shadow-[0_0_50px_rgba(34,197,94,0.2)]' 
                  : 'bg-white border-slate-200 shadow-slate-200'}`}>
                  
                  {/* Mock Browser Header */}
                  <div className={`h-12 border-b flex items-center px-4 gap-2
                    ${isNight ? 'bg-gray-900 border-green-900/30' : 'bg-slate-50 border-slate-200'}`}>
                     <div className="flex gap-2">
                        <div className={`w-3 h-3 rounded-full ${isNight ? 'bg-red-900' : 'bg-slate-300'}`} />
                        <div className={`w-3 h-3 rounded-full ${isNight ? 'bg-yellow-900' : 'bg-slate-300'}`} />
                        <div className={`w-3 h-3 rounded-full ${isNight ? 'bg-green-900' : 'bg-slate-300'}`} />
                     </div>
                     <div className={`ml-4 text-xs px-3 py-1 rounded flex-1 text-center font-mono opacity-50
                       ${isNight ? 'bg-black text-green-500' : 'bg-white text-slate-400'}`}>
                       {isNight ? '127.0.0.1:8080/root' : 'district-portal.edu/dashboard'}
                     </div>
                  </div>

                  {/* Mock Content Body */}
                  <div className="p-8 grid grid-cols-3 gap-6 h-[400px]">
                     {/* Sidebar Mock */}
                     <div className={`hidden md:block col-span-1 rounded-lg border p-4 space-y-3
                       ${isNight ? 'border-green-900/30 bg-green-900/5' : 'border-slate-100 bg-slate-50'}`}>
                        {[1,2,3,4].map(i => (
                           <div key={i} className={`h-8 w-full rounded animate-pulse
                             ${isNight ? 'bg-green-900/20' : 'bg-slate-200'}`} style={{opacity: 1 - (i * 0.15)}} />
                        ))}
                     </div>
                     
                     {/* Main Content Mock */}
                     <div className="col-span-3 md:col-span-2 space-y-6">
                        <div className="flex justify-between items-center">
                           <div className={`h-8 w-1/3 rounded ${isNight ? 'bg-green-500/20' : 'bg-slate-800'}`} />
                           <div className={`h-8 w-1/4 rounded ${isNight ? 'bg-purple-500/20' : 'bg-blue-100'}`} />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                           <div className={`h-32 rounded-lg border p-4
                             ${isNight ? 'border-green-500 text-green-400 bg-black' : 'border-slate-200 bg-white'}`}>
                              <div className={`text-xs uppercase font-bold mb-2 ${isNight ? 'text-gray-500' : 'text-slate-400'}`}>
                                 {isNight ? 'NODE_STATUS' : 'Daily Attendance'}
                              </div>
                              <div className="text-4xl font-bold">
                                 {isNight ? '98%' : '98.4%'}
                              </div>
                           </div>
                           <div className={`h-32 rounded-lg border p-4
                             ${isNight ? 'border-purple-500 text-purple-400 bg-black' : 'border-slate-200 bg-white'}`}>
                              <div className={`text-xs uppercase font-bold mb-2 ${isNight ? 'text-gray-500' : 'text-slate-400'}`}>
                                 {isNight ? 'XP_GAINED' : 'Risk Incidents'}
                              </div>
                              <div className="text-4xl font-bold">
                                 {isNight ? '+4,021' : '0'}
                              </div>
                           </div>
                        </div>

                        <div className={`h-full rounded-lg border p-4 flex items-center justify-center
                          ${isNight ? 'border-gray-800 bg-gray-900/50' : 'border-slate-200 bg-slate-50'}`}>
                           <span className={`text-sm ${isNight ? 'text-gray-600' : 'text-slate-400'}`}>
                              {isNight ? 'AWAITING_INPUT...' : 'No recent alerts.'}
                           </span>
                        </div>
                     </div>
                  </div>

                  {/* Overlay Text */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                     <div className={`px-6 py-3 rounded-full backdrop-blur-xl border shadow-2xl transform translate-y-32
                       ${isNight ? 'bg-black/60 border-green-500 text-green-400' : 'bg-white/80 border-white text-slate-800'}`}>
                        <span className="font-bold mr-2">{isNight ? 'VIEW:' : 'VIEW:'}</span>
                        {isNight ? 'The Creator Nation' : 'The Infrastructure Company'}
                     </div>
                  </div>
              </div>
           </div>
        </div>
      </main>

      {/* Feature Grid */}
      <section className={`py-24 border-t transition-colors duration-500
        ${isNight ? 'bg-[#0A0A0A] border-gray-900' : 'bg-slate-50 border-slate-200'}`}>
         <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
               {isNight ? (
                  // NIGHT FEATURES
                  <>
                    <FeatureCard 
                       icon={<Terminal size={32} className="text-purple-500" />}
                       title="Skill Trees"
                       desc="Forget grades. Unlock nodes in your personal skill tree. Demonstrate mastery in Python, 3D Design, and AI Prompting."
                       mode="NIGHT"
                    />
                    <FeatureCard 
                       icon={<Network size={32} className="text-green-500" />}
                       title="Decentralized ID"
                       desc="Your data belongs to you. Export your entire educational history to a portable wallet when you graduate."
                       mode="NIGHT"
                    />
                    <FeatureCard 
                       icon={<Zap size={32} className="text-yellow-500" />}
                       title="Shadow Modes"
                       desc="Customize your interface. Run dark mode scripts. Build plugins. The platform is yours to hack."
                       mode="NIGHT"
                    />
                  </>
               ) : (
                  // DAY FEATURES
                  <>
                    <FeatureCard 
                       icon={<Lock size={32} className="text-blue-600" />}
                       title="Ironclad Compliance"
                       desc="FERPA, COPPA, and CIPA compliant out of the box. Automated PII redaction on all AI interactions."
                       mode="DAY"
                    />
                    <FeatureCard 
                       icon={<BarChart3 size={32} className="text-indigo-600" />}
                       title="District Analytics"
                       desc="Real-time dashboards showing utilization, risk flags, and learning outcomes across 50+ schools."
                       mode="DAY"
                    />
                    <FeatureCard 
                       icon={<Globe size={32} className="text-cyan-600" />}
                       title="Universal Rostering"
                       desc="One-click sync with ClassLink, Clever, and PowerSchool. Onboard 50,000 students in under an hour."
                       mode="DAY"
                    />
                  </>
               )}
            </div>
         </div>
      </section>

      {/* CTA Section */}
      <section className={`py-32 relative overflow-hidden transition-colors duration-500
        ${isNight ? 'bg-black' : 'bg-slate-900'}`}>
         
         {/* Background Decoration */}
         <div className="absolute inset-0 opacity-30 pointer-events-none">
             <div className={`absolute -top-24 -right-24 w-96 h-96 rounded-full blur-3xl
               ${isNight ? 'bg-green-600' : 'bg-blue-600'}`} />
             <div className={`absolute -bottom-24 -left-24 w-96 h-96 rounded-full blur-3xl
               ${isNight ? 'bg-purple-600' : 'bg-indigo-600'}`} />
         </div>

         <div className="container mx-auto px-6 text-center relative z-10">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
               {isNight ? 'Ready to Jack In?' : 'Secure Your District Today.'}
            </h2>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
               {isNight 
                 ? 'Join 50,000 other architects building the future of the open web.' 
                 : 'Schedule a consultation with our safety experts and receive a custom deployment plan.'}
            </p>
            <button 
              onClick={() => navigate('/login')}
              className={`px-8 py-4 rounded-xl font-bold text-lg flex items-center gap-3 mx-auto transition-all hover:scale-105
              ${isNight 
                ? 'bg-transparent border-2 border-green-500 text-green-400 hover:bg-green-900/20' 
                : 'bg-white text-slate-900 hover:bg-slate-100'}`}>
               {isNight ? 'ENTER_GATEWAY' : 'Get Started'}
               <ArrowRight size={20} />
            </button>
         </div>
      </section>

      {/* Footer */}
      <footer className={`py-12 border-t ${isNight ? 'bg-black border-gray-900 text-gray-600' : 'bg-slate-50 border-slate-200 text-slate-500'}`}>
         <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2 font-bold">
               {isNight ? <Cpu size={20} /> : <School size={20} />}
               <span>AeThex Inc.</span>
            </div>
            <div className="text-sm">
               © 2024 AeThex. {isNight ? 'All Rights Reversed.' : 'All Rights Reserved.'}
            </div>
         </div>
      </footer>

    </div>
  );
};

const FeatureCard: React.FC<{ icon: React.ReactNode, title: string, desc: string, mode: 'DAY' | 'NIGHT' }> = ({ icon, title, desc, mode }) => (
  <div className={`p-8 rounded-2xl transition-all duration-300 hover:translate-y-[-5px]
    ${mode === 'NIGHT' 
      ? 'bg-gray-900/40 border border-gray-800 hover:border-green-500/50' 
      : 'bg-white border border-slate-100 shadow-xl shadow-slate-200/50'}`}>
     <div className={`mb-6 p-3 rounded-xl w-fit ${mode === 'NIGHT' ? 'bg-black border border-gray-700' : 'bg-slate-50'}`}>
        {icon}
     </div>
     <h3 className={`text-xl font-bold mb-3 ${mode === 'NIGHT' ? 'text-white font-mono' : 'text-slate-900'}`}>
        {title}
     </h3>
     <p className={`${mode === 'NIGHT' ? 'text-gray-400' : 'text-slate-500'} leading-relaxed`}>
        {desc}
     </p>
  </div>
);
