
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import { InterfaceMode } from '../types';
import { 
  LayoutDashboard, 
  BookOpen, 
  Settings, 
  Terminal, 
  Target, 
  Network, 
  LogOut,
  School,
  Cpu,
  ShieldAlert,
  Users,
  Activity
} from 'lucide-react';

interface SidebarProps {
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onLogout }) => {
  const { mode } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const isDay = mode === InterfaceMode.DAY;

  // Day Mode Navigation (Enterprise)
  const dayLinks = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Overview' },
    { path: '/audit', icon: ShieldAlert, label: 'Compliance Logs' },
    { path: '/roster', icon: Users, label: 'User Management' },
    { path: '/settings', icon: Settings, label: 'District Config' },
  ];

  // Night Mode Navigation (Cyberpunk)
  const nightLinks = [
    { path: '/dashboard', icon: Terminal, label: 'Command Center' },
    { path: '/audit', icon: Activity, label: 'Net Logs' },
    { path: '/roster', icon: Network, label: 'Guild Members' },
    { path: '/profile', icon: Target, label: 'My Passport' },
  ];

  const links = isDay ? dayLinks : nightLinks;

  const handleLogout = () => {
    onLogout();
    navigate('/login');
  };

  return (
    <aside className={`flex flex-col h-full transition-all duration-700 border-r z-20
      ${isDay 
        ? 'bg-white border-slate-200 w-64' 
        : 'bg-black border-gray-800 w-20 lg:w-64'}`}
    >
      {/* Brand Header */}
      <div className={`p-6 flex items-center gap-3 ${isDay ? 'border-b border-slate-100' : 'border-b border-gray-900'}`}>
        <div className={`p-2 rounded-lg transition-colors duration-500
          ${isDay ? 'bg-blue-600 text-white' : 'bg-green-500/20 text-green-400 border border-green-500'}`}>
          {isDay ? <School size={24} /> : <Cpu size={24} />}
        </div>
        <span className={`font-bold text-lg hidden lg:block transition-opacity duration-300
          ${isDay ? 'text-slate-800 font-sans' : 'text-white font-mono tracking-widest'}`}>
          {isDay ? 'AeThex' : 'AETHEX'}
        </span>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 py-6 space-y-2 px-3">
        {links.map((link) => {
          const isActive = location.pathname === link.path;
          return (
            <button
              key={link.path}
              onClick={() => navigate(link.path)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-300 group
                ${isDay 
                  ? (isActive ? 'bg-blue-50 text-blue-700' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900') 
                  : (isActive ? 'bg-green-900/20 text-green-400 border border-green-500/30' : 'text-gray-500 hover:text-gray-300 hover:bg-white/5')
                }`}
            >
              <link.icon size={20} className={isDay ? '' : 'group-hover:animate-pulse'} />
              <span className={`font-medium hidden lg:block text-left ${isDay ? 'font-sans' : 'font-mono text-sm'}`}>
                {link.label}
              </span>
              {isActive && !isDay && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_5px_#22c55e] hidden lg:block" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Actions */}
      <div className={`p-4 border-t ${isDay ? 'border-slate-100' : 'border-gray-900'}`}>
        <button 
          onClick={handleLogout}
          className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all
            ${isDay 
              ? 'text-slate-500 hover:bg-red-50 hover:text-red-600' 
              : 'text-gray-600 hover:text-red-400 hover:bg-red-900/10 font-mono text-sm'}`}
        >
          <LogOut size={20} />
          <span className="hidden lg:block">Sign Out</span>
        </button>
      </div>
    </aside>
  );
};
