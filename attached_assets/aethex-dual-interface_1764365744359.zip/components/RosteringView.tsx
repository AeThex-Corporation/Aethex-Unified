
import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { InterfaceMode } from '../types';
import { ROSTER_DATA } from '../services/mockData';
import { Upload, Plus, MoreHorizontal, Download, Wifi, WifiOff, Smartphone } from 'lucide-react';

export const RosteringView: React.FC = () => {
  const { mode } = useTheme();
  const isDay = mode === InterfaceMode.DAY;

  return (
    <div className="container mx-auto px-4 py-6 h-full flex flex-col gap-6">
      
      {/* Header */}
      <div className="flex justify-between items-end">
         <div>
            <h1 className={`text-2xl font-bold transition-colors duration-500 mb-2
              ${isDay ? 'text-slate-900' : 'text-white font-mono'}`}>
              {isDay ? 'User Management' : 'ACTIVE_NODE_MAP'}
            </h1>
            <p className={`text-sm ${isDay ? 'text-slate-500' : 'text-gray-500 font-mono'}`}>
              {isDay ? 'Manage student roster, access levels, and integrations.' : 'Scanning local subnet for active agents...'}
            </p>
         </div>
         
         {/* The "Wizard of Oz" Import Button */}
         <button className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all
           ${isDay 
             ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-600/20' 
             : 'bg-green-600 text-black hover:bg-green-500 font-mono shadow-[0_0_15px_rgba(34,197,94,0.5)]'}`}>
           {isDay ? <Upload size={18} /> : <Wifi size={18} />}
           {isDay ? 'Import CSV from ClassLink' : 'SCAN_NETWORK'}
         </button>
      </div>

      {/* Main Content */}
      <div className={`flex-1 rounded-xl border overflow-hidden flex flex-col
        ${isDay ? 'bg-white border-slate-200 shadow-sm' : 'bg-black border-green-900/30'}`}>
        
        {/* Day Mode Roster Table */}
        {isDay && (
          <div className="overflow-x-auto">
             <table className="w-full text-left text-sm">
               <thead className="bg-slate-50 border-b border-slate-200 text-slate-500">
                 <tr>
                   <th className="px-6 py-3 font-semibold">Name</th>
                   <th className="px-6 py-3 font-semibold">Student ID</th>
                   <th className="px-6 py-3 font-semibold">Grade</th>
                   <th className="px-6 py-3 font-semibold">Status</th>
                   <th className="px-6 py-3 font-semibold">Last Login</th>
                   <th className="px-6 py-3 font-semibold text-right">Actions</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                 {ROSTER_DATA.map((student) => (
                   <tr key={student.id} className="hover:bg-slate-50">
                     <td className="px-6 py-4">
                       <div className="font-bold text-slate-900">{student.name}</div>
                       <div className="text-xs text-slate-500">{student.email}</div>
                     </td>
                     <td className="px-6 py-4 text-slate-600 font-mono">{student.id}</td>
                     <td className="px-6 py-4">
                       <span className="px-2 py-1 bg-slate-100 rounded text-xs font-bold text-slate-600">{student.gradeLevel}th</span>
                     </td>
                     <td className="px-6 py-4">
                       <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                         ${student.status === 'Active' ? 'bg-green-100 text-green-800' : 
                           student.status === 'Suspended' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'}`}>
                         {student.status}
                       </span>
                     </td>
                     <td className="px-6 py-4 text-slate-500">{student.lastLogin}</td>
                     <td className="px-6 py-4 text-right">
                       <button className="text-slate-400 hover:text-slate-600"><MoreHorizontal size={20} /></button>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
          </div>
        )}

        {/* Night Mode Node Grid */}
        {!isDay && (
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 overflow-y-auto">
             {ROSTER_DATA.map((student) => (
               <div key={student.id} className="bg-gray-900/30 border border-gray-800 p-4 rounded-lg hover:border-green-500/50 transition-colors group relative overflow-hidden">
                  <div className="flex justify-between items-start mb-4 relative z-10">
                     <div className="w-10 h-10 bg-black border border-gray-700 rounded flex items-center justify-center text-green-500 font-mono text-lg font-bold">
                       {student.name.charAt(0)}
                     </div>
                     <div className={`text-xs font-mono px-2 py-1 border rounded 
                       ${student.status === 'Active' ? 'text-green-400 border-green-900' : 'text-red-400 border-red-900'}`}>
                       {student.status === 'Active' ? 'ONLINE' : 'OFFLINE'}
                     </div>
                  </div>
                  <div className="space-y-2 relative z-10">
                     <div className="text-white font-mono font-bold truncate">{student.name}</div>
                     <div className="text-gray-500 font-mono text-xs">IP: 192.168.1.{Math.floor(Math.random() * 255)}</div>
                     <div className="text-gray-500 font-mono text-xs">HASH: {student.id}</div>
                  </div>
                  
                  {/* Risk Bar */}
                  <div className="mt-4 relative z-10">
                    <div className="flex justify-between text-[10px] text-gray-400 font-mono mb-1">
                      <span>HEAT_LEVEL</span>
                      <span>{student.riskScore}%</span>
                    </div>
                    <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-purple-500" 
                        style={{ width: `${student.riskScore}%` }}
                      />
                    </div>
                  </div>

                  {/* Decorative BG */}
                  <div className="absolute -bottom-4 -right-4 text-gray-800 opacity-20 rotate-12">
                     <Wifi size={100} />
                  </div>
               </div>
             ))}
          </div>
        )}
      </div>
    </div>
  );
};
