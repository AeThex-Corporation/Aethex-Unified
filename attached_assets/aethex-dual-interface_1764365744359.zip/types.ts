
export enum InterfaceMode {
  DAY = 'DAY',
  NIGHT = 'NIGHT'
}

export type ViewType = 'dashboard' | 'chat' | 'profile' | 'settings';

export interface ActivityLogItem {
  id: string;
  timestamp: string;
  action: string;
  context: string; // e.g., "Python Module 1"
  metadata: {
    duration?: string;
    score?: number;
    location?: string;
  };
}

export interface UserProfile {
  name: string;
  idString: string;
  trustScore: number; // 0-100
  role: string;
  avatarUrl: string;
  joinDate: string;
}

export interface SystemState {
  isOnline: boolean;
  lastSync: string;
}

// --- New Types for Dual-Interface Deep Dive ---

export interface ComplianceMetadata {
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'ALLOWED' | 'BLOCKED' | 'FLAGGED';
  piiDetected: boolean;
}

export interface GamificationMetadata {
  skillNodeId: string;
  skillName: string;
  xp: number;
  type: 'UNLOCK' | 'ACHIEVEMENT' | 'QUEST';
  isUnlocked: boolean;
  tier: 'TIER_1' | 'TIER_2' | 'TIER_3';
}

export interface DualEvent {
  id: string;
  timestamp: string;
  studentId: string;
  rawEvent: string;
  compliance: ComplianceMetadata;
  gamification: GamificationMetadata;
}

// --- Enterprise Types ---

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  action: string;
  flagged: boolean;
  trigger: string; // e.g., "PII Detected", "Keyword"
  status: 'BLOCKED' | 'ALLOWED' | 'FLAGGED' | 'QUARANTINED';
}

export interface StudentRosterItem {
  id: string;
  name: string;
  email: string;
  gradeLevel: number;
  status: 'Active' | 'Suspended' | 'Inactive';
  lastLogin: string;
  riskScore: number; // 0-100, high is bad
}
