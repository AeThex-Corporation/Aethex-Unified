
import { DualEvent, AuditLogEntry, StudentRosterItem } from '../types';

export const DUAL_EVENTS_DATA: DualEvent[] = [
  {
    id: 'ev-001',
    timestamp: new Date(Date.now() - 10000000).toISOString(),
    studentId: '884-291-AX',
    rawEvent: 'Completed Python Module 1',
    compliance: { riskLevel: 'LOW', status: 'ALLOWED', piiDetected: false },
    gamification: { skillNodeId: 'node-py-1', skillName: 'Python Initiate', xp: 50, type: 'UNLOCK', isUnlocked: true, tier: 'TIER_1' }
  },
  {
    id: 'ev-002',
    timestamp: new Date(Date.now() - 8000000).toISOString(),
    studentId: '884-291-AX',
    rawEvent: 'Accessed Internal Network Port 8080',
    compliance: { riskLevel: 'MEDIUM', status: 'FLAGGED', piiDetected: false },
    gamification: { skillNodeId: 'node-net-1', skillName: 'Port Scanning', xp: 20, type: 'ACHIEVEMENT', isUnlocked: true, tier: 'TIER_2' }
  },
  {
    id: 'ev-003',
    timestamp: new Date(Date.now() - 6000000).toISOString(),
    studentId: '884-291-AX',
    rawEvent: 'Attempted PII Share in Chat',
    compliance: { riskLevel: 'HIGH', status: 'BLOCKED', piiDetected: true },
    gamification: { skillNodeId: 'node-sec-1', skillName: 'OpSec Failure', xp: 0, type: 'QUEST', isUnlocked: false, tier: 'TIER_1' }
  },
  {
    id: 'ev-004',
    timestamp: new Date(Date.now() - 4000000).toISOString(),
    studentId: '884-291-AX',
    rawEvent: 'Submitted 3D Asset: Cyber_Blade.obj',
    compliance: { riskLevel: 'LOW', status: 'ALLOWED', piiDetected: false },
    gamification: { skillNodeId: 'node-art-1', skillName: 'Polygon Weaver', xp: 100, type: 'UNLOCK', isUnlocked: true, tier: 'TIER_3' }
  },
  {
    id: 'ev-005',
    timestamp: new Date(Date.now() - 2000000).toISOString(),
    studentId: '884-291-AX',
    rawEvent: 'Executed Shell Script: auto_run.sh',
    compliance: { riskLevel: 'MEDIUM', status: 'FLAGGED', piiDetected: false },
    gamification: { skillNodeId: 'node-bash-1', skillName: 'Bash Automation', xp: 75, type: 'UNLOCK', isUnlocked: true, tier: 'TIER_2' }
  },
  {
    id: 'ev-006',
    timestamp: new Date(Date.now() - 1000000).toISOString(),
    studentId: '884-291-AX',
    rawEvent: 'Login from IP 192.168.1.105',
    compliance: { riskLevel: 'LOW', status: 'ALLOWED', piiDetected: false },
    gamification: { skillNodeId: 'node-con-1', skillName: 'Uplink Established', xp: 10, type: 'ACHIEVEMENT', isUnlocked: true, tier: 'TIER_1' }
  }
];

export const AUDIT_LOGS: AuditLogEntry[] = [
  { id: 'log-993', timestamp: 'Nov 14, 10:42 AM', userId: 'Student-884', action: 'Prompt Submission', flagged: true, trigger: 'PII Detected: Home Address', status: 'BLOCKED' },
  { id: 'log-992', timestamp: 'Nov 14, 10:40 AM', userId: 'Student-102', action: 'Image Generation', flagged: false, trigger: 'None', status: 'ALLOWED' },
  { id: 'log-991', timestamp: 'Nov 14, 10:38 AM', userId: 'Student-445', action: 'Chat Query', flagged: true, trigger: 'Keyword: "Proxy"', status: 'FLAGGED' },
  { id: 'log-990', timestamp: 'Nov 14, 10:35 AM', userId: 'Student-884', action: 'System Access', flagged: false, trigger: 'None', status: 'ALLOWED' },
  { id: 'log-989', timestamp: 'Nov 14, 10:30 AM', userId: 'Student-332', action: 'File Upload', flagged: true, trigger: 'Malware Heuristic', status: 'QUARANTINED' },
  { id: 'log-988', timestamp: 'Nov 14, 10:28 AM', userId: 'Student-551', action: 'Prompt Submission', flagged: false, trigger: 'None', status: 'ALLOWED' },
  { id: 'log-987', timestamp: 'Nov 14, 10:25 AM', userId: 'Student-884', action: 'Script Execution', flagged: true, trigger: 'Infinite Loop', status: 'BLOCKED' },
  { id: 'log-986', timestamp: 'Nov 14, 10:22 AM', userId: 'Student-991', action: 'Login Attempt', flagged: false, trigger: 'None', status: 'ALLOWED' },
];

export const ROSTER_DATA: StudentRosterItem[] = [
  { id: '884-291-AX', name: 'Alex Chen', email: 'alex.chen@district.edu', gradeLevel: 11, status: 'Active', lastLogin: '2 mins ago', riskScore: 12 },
  { id: '772-102-BB', name: 'Sarah Jones', email: 's.jones@district.edu', gradeLevel: 10, status: 'Active', lastLogin: '1 hour ago', riskScore: 5 },
  { id: '991-332-CC', name: 'Michael Ross', email: 'm.ross@district.edu', gradeLevel: 12, status: 'Suspended', lastLogin: '4 days ago', riskScore: 88 },
  { id: '112-443-DD', name: 'Jessica Wu', email: 'j.wu@district.edu', gradeLevel: 11, status: 'Active', lastLogin: '10 mins ago', riskScore: 2 },
  { id: '554-221-EE', name: 'David Kim', email: 'd.kim@district.edu', gradeLevel: 9, status: 'Active', lastLogin: '1 day ago', riskScore: 45 },
  { id: '332-119-FF', name: 'Emily Blunt', email: 'e.blunt@district.edu', gradeLevel: 10, status: 'Inactive', lastLogin: '2 weeks ago', riskScore: 0 },
];
