import { GoogleGenAI, Type } from "@google/genai";
import { InterfaceMode, ActivityLogItem } from "../types";

// Lazy initialization to prevent crashes if process is not defined in browser scope immediately
let ai: GoogleGenAI | null = null;

const getAI = () => {
  if (!ai) {
    try {
      // Safely access process.env
      const apiKey = (typeof process !== 'undefined' && process.env) ? process.env.API_KEY : '';
      if (apiKey) {
        ai = new GoogleGenAI({ apiKey });
      }
    } catch (e) {
      console.error("Failed to initialize Gemini client", e);
    }
  }
  return ai;
};

/**
 * Generates a new activity log entry. 
 * The 'magic' here is that we ask Gemini to generate the raw data,
 * but the UI decides how to "spin" that story based on the mode.
 */
export const generateSimulationEvent = async (mode: InterfaceMode): Promise<ActivityLogItem | null> => {
  const client = getAI();
  
  if (!client) {
    console.warn("Gemini Client not ready. Using fallback.");
    return createFallbackData();
  }

  try {
    const prompt = `
      Generate a single JSON object representing a user activity event in a gamified education system.
      The user is "Alex Chen", a student who is also a coding enthusiast.
      
      The event should be ambiguous enough to be interpreted as "Educational Compliance" (Day Mode) or "Hacker Achievement" (Night Mode).
      
      Example contexts:
      - Completing a Python script (Compliance: "Assignment Submitted", Hacker: "Script Executed")
      - 3D Modeling (Compliance: "Art Class Project", Hacker: "Asset Compiled")
      - Late night login (Compliance: "After-hours Study", Hacker: "Stealth Login")

      Return ONLY the JSON object.
    `;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            timestamp: { type: Type.STRING },
            action: { type: Type.STRING, description: "A neutral action verb like 'Completed', 'Accessed', 'Uploaded'" },
            context: { type: Type.STRING, description: "The object of the action, e.g., 'Python Module 4', 'Server 9'" },
            metadata: {
              type: Type.OBJECT,
              properties: {
                duration: { type: Type.STRING },
                score: { type: Type.NUMBER },
                location: { type: Type.STRING }
              }
            }
          }
        }
      }
    });

    if (response.text) {
      const data = JSON.parse(response.text) as ActivityLogItem;
      // Ensure timestamp is fresh for the demo
      data.timestamp = new Date().toISOString(); 
      return data;
    }
    return createFallbackData();

  } catch (error) {
    console.error("Gemini generation failed:", error);
    return createFallbackData();
  }
};

const createFallbackData = (): ActivityLogItem => ({
  id: `fallback-${Date.now()}`,
  timestamp: new Date().toISOString(),
  action: "Executed",
  context: "System Diagnostics",
  metadata: { duration: "120ms", score: 100, location: "Localhost" }
});