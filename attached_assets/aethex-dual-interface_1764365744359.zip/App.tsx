
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { NotificationProvider } from './context/NotificationContext';
import { NotificationSystem } from './components/NotificationSystem';
import { DashboardLayout } from './components/DashboardLayout';
import { LoginPage } from './components/LoginPage';
import { DashboardView } from './components/DashboardView';
import { PassportProfile } from './components/PassportProfile';
import { DistrictConfig } from './components/DistrictConfig';
import { SecureChat } from './components/SecureChat';
import { ComplianceLog } from './components/ComplianceLog';
import { RosteringView } from './components/RosteringView';
import { LandingPage } from './components/LandingPage';
import { UserProfile } from './types';

// Mock User Data reused across routes
const SHARED_USER_DATA: UserProfile = {
  name: "Alex Chen",
  idString: "884-291-AX",
  trustScore: 98,
  role: "STUDENT",
  avatarUrl: "https://picsum.photos/200/200",
  joinDate: "2023-09-01"
};

function App() {
  return (
    <ThemeProvider>
      <NotificationProvider>
        <NotificationSystem />
        <HashRouter>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage onLogin={() => {}} />} />
            
            {/* Protected Dashboard Routes */}
            <Route element={<DashboardLayout onLogout={() => {}} />}>
              <Route path="/dashboard" element={<DashboardView />} />
              <Route path="/audit" element={<ComplianceLog />} />
              <Route path="/roster" element={<RosteringView />} />
              <Route path="/profile" element={<PassportProfile user={SHARED_USER_DATA} />} />
              <Route path="/settings" element={<div className="p-6"><DistrictConfig /></div>} />
              <Route path="/chat" element={<div className="p-6 h-full"><SecureChat /></div>} />
            </Route>
            
            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </HashRouter>
      </NotificationProvider>
    </ThemeProvider>
  );
}

export default App;
