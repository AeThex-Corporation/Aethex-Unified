import React, { createContext, useContext, useState, ReactNode } from 'react';
import { InterfaceMode } from '../types';

interface ThemeContextType {
  mode: InterfaceMode;
  toggleMode: () => void;
  setMode: (mode: InterfaceMode) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [mode, setModeState] = useState<InterfaceMode>(InterfaceMode.DAY);

  const toggleMode = () => {
    setModeState((prev) => (prev === InterfaceMode.DAY ? InterfaceMode.NIGHT : InterfaceMode.DAY));
  };

  const setMode = (newMode: InterfaceMode) => {
    setModeState(newMode);
  };

  return (
    <ThemeContext.Provider value={{ mode, toggleMode, setMode }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};